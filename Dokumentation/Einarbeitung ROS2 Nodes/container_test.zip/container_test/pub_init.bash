#!/bin/bash
source /opt/ros/jazzy/setup.bash;
# rosdep update;
# rosdep install -i --from-path src --rosdistro jazzy -y;
# colcon build --packages-select first_package;
python3 unzip.py "install.zip"
source install/local_setup.bash;
ros2 run first_package simple_pub;
