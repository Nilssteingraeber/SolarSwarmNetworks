import sys
from time import sleep, time

from rcl_interfaces.msg import ParameterDescriptor
from custom_interfaces.srv import EchoServiceIf
import rclpy
from rclpy.node import Node


class EchoClient(Node):

    def __init__(self):
        super().__init__('echo_client')
        self.cli = self.create_client(EchoServiceIf, 'echo_service_if')
        
        self.declare_parameter('nid', '0', ParameterDescriptor(description='Eine nutzerdefinierte ID der Node'))
        
        self.declare_parameter('msg', 'Default message', ParameterDescriptor(description='Zu schickende Nachricht'))
        
        while not self.cli.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('service not available, waiting again...')
        self.req = EchoServiceIf.Request()

    def send_request(self):
        self.req.nid = self.get_parameter('nid').get_parameter_value().string_value
        self.req.msg = self.get_parameter('msg').get_parameter_value().string_value
        return self.cli.call_async(self.req)


def main():
    t0 = time()
    rclpy.init()
    t1 = time()
    # print('------') # zeigt klarer, dass Initialisierung von EchoClient auf Service Server wartet
    echo_client = EchoClient()
    t2 = time()
    echo_client.get_logger().info('rclp init:\t%f' % (t1-t0,))
    echo_client.get_logger().info('EchoClient init:\t%f' % (t2-t1,))
    
    #for i in range (0, 11):
    while True:
        t3 = time()
        future = echo_client.send_request()
        rclpy.spin_until_future_complete(echo_client, future)
        response = future.result()
        t4 = time()
        echo_client.get_logger().info('Echo received after %f s: %s' % (t4-t3, response.msg))
        sleep(5)
    
    echo_client.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
