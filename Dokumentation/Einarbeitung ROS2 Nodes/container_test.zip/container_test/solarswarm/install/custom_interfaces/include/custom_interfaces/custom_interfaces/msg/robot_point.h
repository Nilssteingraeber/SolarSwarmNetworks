// generated from rosidl_generator_c/resource/idl.h.em
// with input from custom_interfaces:msg/RobotPoint.idl
// generated code does not contain a copyright notice

#ifndef CUSTOM_INTERFACES__MSG__ROBOT_POINT_H_
#define CUSTOM_INTERFACES__MSG__ROBOT_POINT_H_

#include "custom_interfaces/msg/detail/robot_point__struct.h"
#include "custom_interfaces/msg/detail/robot_point__functions.h"
#include "custom_interfaces/msg/detail/robot_point__type_support.h"

#endif  // CUSTOM_INTERFACES__MSG__ROBOT_POINT_H_
