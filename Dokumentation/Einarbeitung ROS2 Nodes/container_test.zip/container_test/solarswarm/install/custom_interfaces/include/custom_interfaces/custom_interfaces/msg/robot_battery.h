// generated from rosidl_generator_c/resource/idl.h.em
// with input from custom_interfaces:msg/RobotBattery.idl
// generated code does not contain a copyright notice

#ifndef CUSTOM_INTERFACES__MSG__ROBOT_BATTERY_H_
#define CUSTOM_INTERFACES__MSG__ROBOT_BATTERY_H_

#include "custom_interfaces/msg/detail/robot_battery__struct.h"
#include "custom_interfaces/msg/detail/robot_battery__functions.h"
#include "custom_interfaces/msg/detail/robot_battery__type_support.h"

#endif  // CUSTOM_INTERFACES__MSG__ROBOT_BATTERY_H_
