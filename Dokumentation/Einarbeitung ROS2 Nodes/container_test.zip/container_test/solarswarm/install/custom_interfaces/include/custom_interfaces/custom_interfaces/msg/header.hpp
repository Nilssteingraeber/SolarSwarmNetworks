// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CUSTOM_INTERFACES__MSG__HEADER_HPP_
#define CUSTOM_INTERFACES__MSG__HEADER_HPP_

#include "custom_interfaces/msg/detail/header__struct.hpp"
#include "custom_interfaces/msg/detail/header__builder.hpp"
#include "custom_interfaces/msg/detail/header__traits.hpp"
#include "custom_interfaces/msg/detail/header__type_support.hpp"

#endif  // CUSTOM_INTERFACES__MSG__HEADER_HPP_
