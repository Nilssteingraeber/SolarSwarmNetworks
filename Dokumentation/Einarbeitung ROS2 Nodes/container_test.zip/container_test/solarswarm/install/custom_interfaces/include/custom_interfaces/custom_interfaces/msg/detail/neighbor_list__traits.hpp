// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from custom_interfaces:msg/NeighborList.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "custom_interfaces/msg/neighbor_list.hpp"


#ifndef CUSTOM_INTERFACES__MSG__DETAIL__NEIGHBOR_LIST__TRAITS_HPP_
#define CUSTOM_INTERFACES__MSG__DETAIL__NEIGHBOR_LIST__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "custom_interfaces/msg/detail/neighbor_list__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "custom_interfaces/msg/detail/header__traits.hpp"

namespace custom_interfaces
{

namespace msg
{

inline void to_flow_style_yaml(
  const NeighborList & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: neighbors
  {
    if (msg.neighbors.size() == 0) {
      out << "neighbors: []";
    } else {
      out << "neighbors: [";
      size_t pending_items = msg.neighbors.size();
      for (auto item : msg.neighbors) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: indicators
  {
    if (msg.indicators.size() == 0) {
      out << "indicators: []";
    } else {
      out << "indicators: [";
      size_t pending_items = msg.indicators.size();
      for (auto item : msg.indicators) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const NeighborList & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: neighbors
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.neighbors.size() == 0) {
      out << "neighbors: []\n";
    } else {
      out << "neighbors:\n";
      for (auto item : msg.neighbors) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: indicators
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.indicators.size() == 0) {
      out << "indicators: []\n";
    } else {
      out << "indicators:\n";
      for (auto item : msg.indicators) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const NeighborList & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace custom_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use custom_interfaces::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const custom_interfaces::msg::NeighborList & msg,
  std::ostream & out, size_t indentation = 0)
{
  custom_interfaces::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use custom_interfaces::msg::to_yaml() instead")]]
inline std::string to_yaml(const custom_interfaces::msg::NeighborList & msg)
{
  return custom_interfaces::msg::to_yaml(msg);
}

template<>
inline const char * data_type<custom_interfaces::msg::NeighborList>()
{
  return "custom_interfaces::msg::NeighborList";
}

template<>
inline const char * name<custom_interfaces::msg::NeighborList>()
{
  return "custom_interfaces/msg/NeighborList";
}

template<>
struct has_fixed_size<custom_interfaces::msg::NeighborList>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<custom_interfaces::msg::NeighborList>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<custom_interfaces::msg::NeighborList>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // CUSTOM_INTERFACES__MSG__DETAIL__NEIGHBOR_LIST__TRAITS_HPP_
