import rclpy
from rclpy.node import Node
from rcl_interfaces.msg import ParameterDescriptor
# from example_interfaces.msg import String
# from example_interfaces.msg import Float64
# from geometry_msgs.msg import Point
# from geometry_msgs.msg import Quaternion
from custom_interfaces.srv import SetRobotActivity
from custom_interfaces.srv import RobotServiceInfo
from custom_interfaces.srv import RobotInterfaceInfo
from custom_interfaces.msg import RobotBattery
from custom_interfaces.msg import RobotCpu
from custom_interfaces.msg import RobotPoint
from custom_interfaces.msg import RobotQuaternion
from custom_interfaces.msg import RobotMisc

from socket import gethostbyname, gethostname
from datetime import datetime
from random import random, randint
from numpy import array
from numpy.linalg import norm
import psutil, re, uuid, os, json

# activity name constants (in case they are renamed later)
# must be imported or set if MockRobotStatusPub is used in another module 
AUTO = 'auto'
IDLE = 'idle'
MANU = 'manual'
RECH = 'recharge'

# determine nid from hashed mac
_MAC = ':'.join(re.findall('..', '%012x' % uuid.getnode()))
_NID = _MAC.replace(':', '')
print(_MAC, _NID)

class MockRobotStatusPub(Node):
    def __init__(self):
        # assign node name
        super().__init__('mock_robot_status_pub_%s' % (_NID,))
        self.__mac = _MAC
        # declare parameters
        self.declare_parameter('system_intervall', 3.0, ParameterDescriptor(description='Time it takes for battery and cpu to be published again.'))
        self.declare_parameter('geo_intervall', 1.0, ParameterDescriptor(description='Time it takes for point and orientation to be published again.'))
        self.declare_parameter('misc_intervall', 20.0, ParameterDescriptor(description='Time it takes for a json string to be published again.'))
        self.get_logger().debug('Parameters declared')
        
        # mock nid
        self.__nid = _NID 
        
        # robot activity
        self.__allowed_activities = [AUTO, IDLE, MANU, RECH]
        self.__activity = AUTO
        
        # init services
        self.__activity_srv = self.create_service(SetRobotActivity, 'set_robot_activity_%s' % (self.__nid,), self.set_activity_callback) 
        self.service_info_srv = self.create_service(RobotServiceInfo, 'robot_service_info_%s' % (self.__nid,), self.service_info_callback)
        self.interface_info_srv = self.create_service(RobotInterfaceInfo, 'robot_interface_info_%s' % (self.__nid,), self.interface_info_callback)
        
        # init publishers
        self.__battery_pub = self.create_publisher(RobotBattery, 'robot_battery', 3) # as percent, i.e. 78.46
        self.__cpu_pub = self.create_publisher(RobotCpu, 'robot_cpu', 3) # as percentage, i.e. 34.00
        self.__point_pub = self.create_publisher(RobotPoint, 'robot_point', 3)
        self.__orientation_pub = self.create_publisher(RobotQuaternion, 'robot_orientation', 3)
        self.__misc_pub = self.create_publisher(RobotMisc, 'robot_misc', 3)
        self.get_logger().debug('Publishers initialized')
        
        # timer intervalls
        SYSTEM = rclpy.parameter.parameter_value_to_python(
            self.get_parameter('system_intervall').get_parameter_value())
        GEO = rclpy.parameter.parameter_value_to_python(
            self.get_parameter('geo_intervall').get_parameter_value())
        MISC = rclpy.parameter.parameter_value_to_python(
            self.get_parameter('misc_intervall').get_parameter_value())
        
        # init timers
        self.__system_timer = self.create_timer(SYSTEM, self.system_timer_callback)
        self.__geo_timer = self.create_timer(GEO, self.geo_timer_callback)
        self.__misc_timer = self.create_timer(MISC, self.misc_timer_callback)
        self.get_logger().debug('Timers initialized')
        
        # mock coordinates, decimal calculated as a°b'c" -> a + b/60 + c/3600
        # movement is calculated by treating coordinates as points/vectors in a two-dimensional vector space 
        start = array([51.450388888888895, 7.276472222222222]) # 51°27'01.4"N 7°16'35.3"E
        self.__goal = 1 # index of next point in self.points
        self.__max_vec_len = 5.288731323495855e-05 # = norm(start - <first point of case 4>)/12
        self.__mock_routes = [ # has to have at least one route
            # sample route (line) using start as a starting point
            [start, # pass by value
                array([51.44927777777777, 7.2773055555555555])], # 51°26'57.4"N 7°16'38.3"E
            # sample route (triangle) using start as a starting point
            [start,
                array([51.451, 7.276833333333333]), # 51°27'03.6"N 7°16'36.6"E
                array([51.45080555555556, 7.276083333333333])], # 51°27'02.9"N 7°16'33.9"
            # sample route (quadrangle) using start as a starting point
            [start,
                array([51.45063888888889, 7.277055555555555]), # 51°27'02.3"N 7°16'37.4"E
                array([51.451, 7.276833333333333]), # 51°27'03.6"N 7°16'36.6"E
                array([51.45080555555556, 7.276083333333333])], # 51°27'02.9"N 7°16'33.9"E
        ]
        route_variant = randint(0, len(self.__mock_routes)-1)
        self.get_logger().debug('Route %d selected' % (route_variant,))
        self.__points = self.__mock_routes[route_variant]
        self.__current = self.__points[self.__goal] # array is passed by value/copied
    

    # read-only properties
    @property
    def nid(self):
        return self.__nid
    @property
    def mac(self):
        return self.__mac
    @property
    def activity_srv(self):
        return self.__activity_srv
    @property
    def battery_pub(self):
        return self.__battery_pub
    @property
    def cpu_pub(self):
        return self.__cpu_pub
    @property
    def point_pub(self):
        return self.__point_pub
    @property
    def orientation_pub(self):
        return self.__orientation_pub
    @property
    def misc_pub(self):
        return self.__misc_pub
    

    # read and write properties
    @property
    def activity(self):
        return self.__activity
    @activity.setter
    def activity(self, a):
        if a in self.__allowed_activities:
            self.__activity = a

    @property
    def points(self):
        return self.__points
    @points.setter
    def points(self, p):
        if type(p) == type(self.__points) and len(p) > 0: # must be list
            for point in p:
                if type(point) == type(self.__points[0]): # must be numpy.array
                    if len(point) == len(self.__points) and type(point[0]) == type(self.__points[0][0]): # must have same dimension and element type (all elements share one type)
                        self.__points = p
    @property
    def goal(self):
        return self.__goal
    @goal.setter
    def goal(self, g):
        if type(g) == type(self.__goal) and g >= 0 and g < len(self.__points):
            self.__goal = g # valid type and value range
    @property
    def max_vec_len(self):
        return self.__max_vec_len
    @max_vec_len.setter
    def max_vec_len(self, m):
        if type(m) == type(self.__max_vec_len) and m >= 0.0:
            self.__max_vec_len = m # valid type and value
    @property
    def current(self):
        return self.__current
    @current.setter
    def current(self, a):
        if type(a) == type(self.__current) and len(a) == len(self.__current):
            # only checks type and length but not element type
            # as current is set frequently, this setter should not be too expensive
            self.__current = a
            
    

    # service callbacks
    def set_activity_callback(self, request, response): 
        if request.activity in self.__allowed_activities:
            if request.activity == MANU: # match-case statement does not accept MANU and AUTO
                try:
                    temp = self.points
                    point = json.dumps(request.details) # details must contain a json string with at least valid x and y coordinates 
                    self.activity = request.activity
                    self.points = [array([point['x'], point['y']])]
                    if self.points == temp: # self.points is not changed if values are invalid
                        raise ValueError('Failed to set new points.')
                    self.goal = 0
                except ValueError as e:
                    response.msg = e + ' Details could not be translated into a point: The field should contain a json string with at least keys x and y and floats as their values.'
                    return response
            elif request.activity == AUTO:
                try:
                    route = int(request.details)
                    if route >= 0 and route < len(self.__mock_routes):
                        self.points == self.__mock_routes[route]
                except:
                    route_variant = randint(0, len(self.__mock_routes)-1)
                    self.points == self.__mock_routes[route_variant] # if no valid route, pick random
                    self.get_logger().debug('Failed to set points to desired mock route. Route %d was chosen instead.', (route_variant,))
            self.activity = request.activity
            response.msg = 'Activity updated'
            self.get_logger().info('Activity updated to: %s' % (request.activity,))
        else:
            response.msg = 'Activity undefined'

        return response
    
    def service_info_callback(self, request, response):
        try:
            if not request.service: # empty field service
                services_list = os.popen('ros2 service list -t').read().splitlines() # get list of services and respective types
                response.services = services_list
                response.msg = '%d services found' % (len(services_list),)
            else: # filter using field service
                if request.service.replace('_', '').replace('/', '').isalnum(): # check for legal input
                    services_list = os.popen('ros2 service list -t | grep %s' % (request.service,)).read().splitlines()
                    response.services = services_list
                    response.msg = '%d filtered services found' % (len(services_list),)
                else:
                    response.msg = 'Service failed: Field service contained illegal characters (must be alphanumeric or _)'
                    response.services = []
        except Exception as e:
                response.msg = 'Service failed: An error has occurred'
                response.services = []
                print('Error in service_info_callback:', e)
        return response
    
    def interface_info_callback(self, request, response):
        try:
            interface_list = os.popen('ros2 interface list').read().splitlines()
            if request.interface in interface_list:
                response.definition = os.popen('ros2 interface show').read()
                response.interfaces = []
            else:
                response.definition = ''
                response.interfaces = interface_list
        except Exception as e:
                response.msg = 'Service failed: An error has occurred'
                print('Error in interface_info_callback:', e)
        return response
    
    # timer callbacks
    def system_timer_callback(self):
        # battery
        msg = RobotBattery()
        msg.nid = self.nid
        battery = psutil.sensors_battery()
        if battery != None: # sensors_battery() returns None-object if battery can not be found
            msg.data = battery.percent
        else:
            msg.data = -1.0
            
        self.battery_pub.publish(msg)
        
        # cpu
        msg = RobotCpu()
        load1, load5, load15 = psutil.getloadavg() # returns 3 values
        msg.nid = self.nid
        msg.data = (load1 / os.cpu_count()) * 100 # average of last minute
        
        self.cpu_pub.publish(msg)
    
    def geo_timer_callback(self):
        # point
        # simulate movement towards coordinate goal
        if not self.__activity in (IDLE, RECH):
            vec_to_point = self.points[self.goal] - self.current # calculate vector to next point
            vec_len = norm(vec_to_point) # calculate vector length
            if vec_len > self.max_vec_len and vec_len != 0:
                self.get_logger().debug('Vector: %s' % (str(vec_to_point),))
                vec_to_point = vec_to_point * (self.max_vec_len/vec_len) # shorten vector to max_vec_len
                # if, for instance, vec_len is twice as large as max_vec_len, vec_to_point will be halved
                self.current = self.current + vec_to_point # move towards goal
            else:
                self.current = self.points[self.goal] # move distance <= max_vec_len towards goal
                self.get_logger().debug('Reached point %d' % (self.goal,))
                if self.activity == AUTO:
                    self.goal = (self.goal+1) % len(self.points) # determine next goal (cylces back to first)
                else:
                    self.activity = IDLE
        
        msg = RobotPoint()
        msg.nid = self.nid
        msg.x = float(self.current[0]) # arrays contain numpy.float objects, but geometry_messages requires float
        msg.y = float(self.current[1])
        msg.z = 0.0
        
        self.point_pub.publish(msg)
        
        # orientation
        msg = RobotQuaternion()
        msg.nid = self.nid
        msg.x = 0.0
        msg.y = 0.0
        msg.z = 0.0
        msg.w = 1.0
        
        self.orientation_pub.publish(msg)
    
    def misc_timer_callback(self):
        data = {}
        
        # MAC
        data["mac"] = self.__mac
        
        # IP
        data["ip"] = gethostbyname(gethostname())
        
        # datetime using format 'year-month-day hour:min:sec.ms'
        data["datetime"] = str(datetime.now())
        
        msg = RobotMisc()
        msg.nid = self.nid
        msg.data = json.dumps(data)
        
        self.misc_pub.publish(msg)



def main():
    # start up
    rclpy.init()
    mock_robot_status_pub = MockRobotStatusPub()
    print("Ready")
    rclpy.spin(mock_robot_status_pub)
    mock_robot_status_pub.get_logger().info('Mock-Robot ready using nid %s' % (str(mock_robot_status_pub.nid),))
    mock_robot_status_pub.get_logger().info('Mock-Robot running')
    
    # shut down
    mock_robot_status_pub.destroy_node()
    mock_robot_status_pub.get_logger().info('Mock-Robot destroyed')
    rclpy.shutdown()
