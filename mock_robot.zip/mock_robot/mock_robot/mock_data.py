import rclpy
from rclpy.node import Node
from rcl_interfaces.msg import ParameterDescriptor
from example_interfaces.msg import String
from example_interfaces.msg import Float64
from geometry_msgs.msg import Point
from geometry_msgs.msg import Quaternion

from socket import gethostbyname, gethostname 
from datetime import datetime
from random import random, randint
from numpy import array
from numpy.linalg import norm
import psutil, re, uuid, os, json


class MockRobotStatusPub(Node):
    def __init__(self):
        # assign node name
        super().__init__('mock_robot_status_pub')
        # declare parameters
        self.declare_parameter('system_intervall', 3.0, ParameterDescriptor(description='Time it takes for battery and cpu to be published again.'))
        self.declare_parameter('geo_intervall', 1.0, ParameterDescriptor(description='Time it takes for point and orientation to be published again.'))
        self.declare_parameter('misc_intervall', 60.0, ParameterDescriptor(description='Time it takes for a json string to be published again.'))
        print('DEBUG: Parameters declared')
        
        # init publishers
        self.__battery_pub = self.create_publisher(Float64, 'robot_battery', 3) # as percent, i.e. 78.46
        self.__cpu_pub = self.create_publisher(Float64, 'robot_cpu', 3) # as percentage, i.e. 34.00
        self.__point_pub = self.create_publisher(Point, 'robot_point', 3)
        self.__orientation_pub = self.create_publisher(Quaternion, 'robot_orientation', 3)
        self.__misc_pub = self.create_publisher(String, 'robot_misc', 3)
        print('DEBUG: Publishers initialized')
        
        # timer intervalls
        SYSTEM = rclpy.parameter.parameter_value_to_python(
            self.get_parameter('system_intervall').get_parameter_value())
        GEO = rclpy.parameter.parameter_value_to_python(
            self.get_parameter('geo_intervall').get_parameter_value())
        MISC = rclpy.parameter.parameter_value_to_python(
            self.get_parameter('misc_intervall').get_parameter_value())
        
        # init timers
        self.system_timer = self.create_timer(SYSTEM, self.system_timer_callback)
        self.geo_timer = self.create_timer(GEO, self.geo_timer_callback)
        self.misc_timer = self.create_timer(MISC, self.misc_timer_callback)
        print('DEBUG: Timers initialized')
        
        # mock coordinates, decimal calculated as a°b'c" -> a + b/60 + c/3600
        # movement is calculated by treating coordinates as points/vectors in a two-dimensional vector space 
        start = array([51.450388888888895, 7.276472222222222]) # 51°27'01.4"N 7°16'35.3"E
        self.goal = 1 # index of next point in self.points
        self.max_vec_len = 5.288731323495855e-05 # = norm(start - <first point of case 4>)/12
        
        self.route_variant = randint(1, 3)
        print('DEBUG: Route', self.route_variant, 'selected')
        match self.route_variant:
            case 1: # sample route (line) using start as a starting point
                self.points = [start,
                    array([51.44927777777777, 7.2773055555555555])] # 51°26'57.4"N 7°16'38.3"E
            case 2: # sample route (triangle) using start as a starting point
                self.points = [start,
                    array([51.451, 7.276833333333333]), # 51°27'03.6"N 7°16'36.6"E
                    array([51.45080555555556, 7.276083333333333])] # 51°27'02.9"N 7°16'33.9"E
            case 3: # sample route (quadrangle) using start as a starting point
                self.points = [start,
                    array([51.45063888888889, 7.277055555555555]) # 51°27'02.3"N 7°16'37.4"E
                    array([51.451, 7.276833333333333]), # 51°27'03.6"N 7°16'36.6"E
                    array([51.45080555555556, 7.276083333333333])] # 51°27'02.9"N 7°16'33.9"E
        self.current = self.points[0] # array is passed by value/copied
    
    def get_battery_pub(self):
        return self.__battery_pub
    
    def get_cpu_pub(self):
        return self.__cpu_pub
    
    def get_point_pub(self):
        return self.__point_pub
        
    def get_orientation_pub(self):
        return self.__orientation_pub
    
    def get_misc_pub(self):
        return self.__misc_pub
    
    def system_timer_callback(self):
        # battery
        msg = Float64()
        battery = psutil.sensors_battery()
        if battery != None: # sensors_battery() returns None-object if battery can not be found
            msg.data = battery.percent
        else:
            msg.data = -1.0
            
        self.get_battery_pub.publish(msg)
        
        # cpu
        load1, load5, load15 = psutil.getloadavg()
        msg.data = (load1 / os.cpu_count()) * 100 # average of last minute
        
        self.get_cpu_pub().publish(msg)
    
    def geo_timer_callback(self):
        # point
        # calculate movement towards coordinate goal
        vec_to_point = self.points[self.goal] - self.current # calculate vector to next point
        vec_len = norm(vec_to_point) # calculate vector length
        if vec_len > self.max_vec_len:
            vec_to_point = vec_to_point * (self.max_vec_len/vec_len) # shorten vector to max_vec_len
            # if, for instance, vec_len is twice as large as max_vec_len, vec_to_point will be halved
            self.current += vec_to_point # move towards goal
        else:
            self.current = self.points[self.goal] # move distance <= max_vec_len towards goal
            print('DEBUG: Reached point', self.goal)
            self.goal = (self.goal+1) % len(self.points) # determine next goal (cylces back to first)
        
        msg = Point()
        msg.x = self.current[0]
        msg.y = self.current[1]
        msg.z = 0
        
        self.get_point_pub().publish(msg)
        
        # orientation
        msg = Quaternion() # currently using interface's default of 0, 0, 0, 1
        
        self.get_orientation_pub().publish(msg)
    
    def misc_timer_callback(self):
        data = {}
        
        # MAC
        data["mac"] = ':'.join(re.findall('..', '%012x' % uuid.getnode()))
        
        # IP
        data["ip"] = gethostbyname(gethostname())
        
        # datetime using format 'year-month-day hour:min:sec.ms'
        data["datetime"] = str(datetime.now())
        
        msg = String()
        msg.data = json.dumps(data)
        
        self.get_misc_pub().publish(msg)
    
def main():
    # start up
    rclpy.init()
    mock_robot_status_pub = MockRobotStatusPub()
    print('DEBUG: Mock-Robot ready')
    rclpy.spin(mock_robot_status_pub)
    print('DEBUG: Mock-Robot running')
    
    # shut down
    mock_robot_status_pub.destroy_node()
    print('DEBUG: Mock-Robot destroyed')
    rclpy.shutdown()
