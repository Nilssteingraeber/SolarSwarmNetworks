import rclpy
from rclpy.node import Node
from rcl_interfaces.msg import ParameterDescriptor
from example_interfaces.msg import String
from example_interfaces.msg import Float64
from geometry_msgs.msg import Point
from geometry_msgs.msg import Quaternion

from socket import gethostbyname, gethostname 
from datetime import datetime
from random import random, randint
import psutil, re, uuid, os, json


class MockRobotStatusPub(Node):
    def __init__(self):
        # assign node name
        super().__init__('mock_robot_status_pub')
        # declare parameters
        self.declare_parameter('system_intervall', 3.0, ParameterDescriptor(description='Time it takes for battery and cpu to be published again.'))
        self.declare_parameter('geo_intervall', 3.0, ParameterDescriptor(description='Time it takes for point and orientation to be published again.'))
        self.declare_parameter('misc_intervall', 60.0, ParameterDescriptor(description='Time it takes for a json string to be published again.'))
        print('DEBUG: Parameters declared')
        
        # init publishers
        self.battery_pub = self.create_publisher(Float64, 'robot_battery', 3) # as percent, i.e. 78.46
        self.cpu_pub = self.create_publisher(Float64, 'robot_cpu', 3) # as percentage, i.e. 34.00
        self.point_pub = self.create_publisher(Point, 'robot_point', 3)
        self.orientation_pub = self.create_publisher(Quaternion, 'robot_orientation', 3)
        self.misc_pub = self.create_publisher(String, 'robot_misc', 3)
        print('DEBUG: Publishers initialized')
        
        # list of mock coordinates
        self.point = []
        for _ in range(3):
            self.point.append(round(random()*100, 4))
        print('DEBUG: Mock point determined')
        
        # timer intervalls
        SYSTEM = rclpy.parameter.parameter_value_to_python(
            self.get_parameter('system_intervall').get_parameter_value())
        GEO = rclpy.parameter.parameter_value_to_python(
            self.get_parameter('geo_intervall').get_parameter_value())
        MISC = rclpy.parameter.parameter_value_to_python(
            self.get_parameter('misc_intervall').get_parameter_value())
        
        # init timers
        self.system_timer = self.create_timer(SYSTEM, self.system_timer_callback)
        self.geo_timer = self.create_timer(GEO, self.geo_timer_callback)
        self.misc_timer = self.create_timer(MISC, self.misc_timer_callback)
        print('DEBUG: Timers initialized')
    
    def system_timer_callback(self):
        # battery
        msg = Float64()
        battery = psutil.sensors_battery()
        if battery != None: # sensors_battery() returns None-object if battery can not be found
            msg.data = battery.percent
        else:
            msg.data = -1.0
            
        self.battery_pub.publish(msg)
        
        # cpu
        load1, load5, load15 = psutil.getloadavg()
        msg.data = (load1 / os.cpu_count()) * 100 # average of last minute
        
        self.cpu_pub.publish(msg)
    
    def geo_timer_callback(self):
        # point using random coordinates with jitter
        msg = Point()
        msg.x = self.point[0] + randint(-10, 10)
        msg.y = self.point[1] + randint(-10, 10)
        msg.z = self.point[2] + randint(-1, 1)
        
        self.point_pub.publish(msg)
        
        # orientation using default (0, 0, 0, 1)
        msg = Quaternion()
        
        self.orientation_pub.publish(msg) # uses default of 0, 0, 0, 1
    
    def misc_timer_callback(self):
        msg = String()
        data = {}
        
        # MAC
        data["mac"] = ':'.join(re.findall('..', '%012x' % uuid.getnode()))
        
        # IP
        data["ip"] = gethostbyname(gethostname())
        
        # datetime using format 'year-month-day hour:min:sec.ms'
        data["datetime"] = str(datetime.now())
        msg.data = json.dumps(data)
        
        self.misc_pub.publish(msg)
    
def main():
    # start up
    rclpy.init()
    mock_robot_status_pub = MockRobotStatusPub()
    print('DEBUG: Mock-Robot ready')
    rclpy.spin(mock_robot_status_pub)
    print('DEBUG: Mock-Robot running')
    
    # shut down
    mock_robot_status_pub.destroy_node()
    print('DEBUG: Mock-Robot destroyed')
    rclpy.shutdown()
