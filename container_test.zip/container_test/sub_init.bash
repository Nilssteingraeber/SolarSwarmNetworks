#!/bin/bash
rosdep update;
rosdep install -i --from-path src --rosdistro jazzy -y;
colcon build --packages-select first_package;
source install/setup.bash;
ros2 run first_package simple_sub;
