// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from custom_interfaces:srv/RobotServiceInfo.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "custom_interfaces/srv/robot_service_info.hpp"


#ifndef CUSTOM_INTERFACES__SRV__DETAIL__ROBOT_SERVICE_INFO__BUILDER_HPP_
#define CUSTOM_INTERFACES__SRV__DETAIL__ROBOT_SERVICE_INFO__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "custom_interfaces/srv/detail/robot_service_info__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace custom_interfaces
{

namespace srv
{

namespace builder
{

class Init_RobotServiceInfo_Request_service
{
public:
  Init_RobotServiceInfo_Request_service()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::custom_interfaces::srv::RobotServiceInfo_Request service(::custom_interfaces::srv::RobotServiceInfo_Request::_service_type arg)
  {
    msg_.service = std::move(arg);
    return std::move(msg_);
  }

private:
  ::custom_interfaces::srv::RobotServiceInfo_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::custom_interfaces::srv::RobotServiceInfo_Request>()
{
  return custom_interfaces::srv::builder::Init_RobotServiceInfo_Request_service();
}

}  // namespace custom_interfaces


namespace custom_interfaces
{

namespace srv
{

namespace builder
{

class Init_RobotServiceInfo_Response_services
{
public:
  explicit Init_RobotServiceInfo_Response_services(::custom_interfaces::srv::RobotServiceInfo_Response & msg)
  : msg_(msg)
  {}
  ::custom_interfaces::srv::RobotServiceInfo_Response services(::custom_interfaces::srv::RobotServiceInfo_Response::_services_type arg)
  {
    msg_.services = std::move(arg);
    return std::move(msg_);
  }

private:
  ::custom_interfaces::srv::RobotServiceInfo_Response msg_;
};

class Init_RobotServiceInfo_Response_msg
{
public:
  Init_RobotServiceInfo_Response_msg()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RobotServiceInfo_Response_services msg(::custom_interfaces::srv::RobotServiceInfo_Response::_msg_type arg)
  {
    msg_.msg = std::move(arg);
    return Init_RobotServiceInfo_Response_services(msg_);
  }

private:
  ::custom_interfaces::srv::RobotServiceInfo_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::custom_interfaces::srv::RobotServiceInfo_Response>()
{
  return custom_interfaces::srv::builder::Init_RobotServiceInfo_Response_msg();
}

}  // namespace custom_interfaces


namespace custom_interfaces
{

namespace srv
{

namespace builder
{

class Init_RobotServiceInfo_Event_response
{
public:
  explicit Init_RobotServiceInfo_Event_response(::custom_interfaces::srv::RobotServiceInfo_Event & msg)
  : msg_(msg)
  {}
  ::custom_interfaces::srv::RobotServiceInfo_Event response(::custom_interfaces::srv::RobotServiceInfo_Event::_response_type arg)
  {
    msg_.response = std::move(arg);
    return std::move(msg_);
  }

private:
  ::custom_interfaces::srv::RobotServiceInfo_Event msg_;
};

class Init_RobotServiceInfo_Event_request
{
public:
  explicit Init_RobotServiceInfo_Event_request(::custom_interfaces::srv::RobotServiceInfo_Event & msg)
  : msg_(msg)
  {}
  Init_RobotServiceInfo_Event_response request(::custom_interfaces::srv::RobotServiceInfo_Event::_request_type arg)
  {
    msg_.request = std::move(arg);
    return Init_RobotServiceInfo_Event_response(msg_);
  }

private:
  ::custom_interfaces::srv::RobotServiceInfo_Event msg_;
};

class Init_RobotServiceInfo_Event_info
{
public:
  Init_RobotServiceInfo_Event_info()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RobotServiceInfo_Event_request info(::custom_interfaces::srv::RobotServiceInfo_Event::_info_type arg)
  {
    msg_.info = std::move(arg);
    return Init_RobotServiceInfo_Event_request(msg_);
  }

private:
  ::custom_interfaces::srv::RobotServiceInfo_Event msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::custom_interfaces::srv::RobotServiceInfo_Event>()
{
  return custom_interfaces::srv::builder::Init_RobotServiceInfo_Event_info();
}

}  // namespace custom_interfaces

#endif  // CUSTOM_INTERFACES__SRV__DETAIL__ROBOT_SERVICE_INFO__BUILDER_HPP_
