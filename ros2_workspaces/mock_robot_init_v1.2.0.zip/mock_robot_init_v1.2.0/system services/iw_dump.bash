#!/bin/bash

# How to use:
# 1. Copy this script into /usr/local/bin using
#      sudo cp iw_dump.bash /usr/local/bin/
# 2. Ensure the script is executable using
#      sudo chmod +x /usr/local/bin/iw_dump.bash
# 3. Copy iw_dump.service and iw_dump.timer into /etc/systemd/system/ using
#      sudo cp iw_dump.service /etc/systemd/system/
#      sudo cp iw_dump.timer /etc/systemd/system
# 4. Reload services and activate timer
#      sudo systemctl daemon-reload
#      sudo systemctl enable --now iw_dump.timer

WLANDEV="wlp0s20f3"
DUMP="/tmp/iw_dump/iw_dump.txt" # note that DUMP must be changed manually in robot_util.py to match any changes made to this path
TMP="${DUMP}.tmp"

if iw dev $WLANDEV station dump > $TMP; then
  mv $TMP $DUMP
else
  echo "Error: iw_dump serivce failed to get station dump"
fi
