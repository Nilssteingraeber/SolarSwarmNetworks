// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CUSTOM_INTERFACES__SRV__SET_ROBOT_ACTIVITY_HPP_
#define CUSTOM_INTERFACES__SRV__SET_ROBOT_ACTIVITY_HPP_

#include "custom_interfaces/srv/detail/set_robot_activity__struct.hpp"
#include "custom_interfaces/srv/detail/set_robot_activity__builder.hpp"
#include "custom_interfaces/srv/detail/set_robot_activity__traits.hpp"
#include "custom_interfaces/srv/detail/set_robot_activity__type_support.hpp"

#endif  // CUSTOM_INTERFACES__SRV__SET_ROBOT_ACTIVITY_HPP_
