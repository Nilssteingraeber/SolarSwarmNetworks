// generated from rosidl_generator_c/resource/idl.h.em
// with input from custom_interfaces:msg/RobotCpu.idl
// generated code does not contain a copyright notice

#ifndef CUSTOM_INTERFACES__MSG__ROBOT_CPU_H_
#define CUSTOM_INTERFACES__MSG__ROBOT_CPU_H_

#include "custom_interfaces/msg/detail/robot_cpu__struct.h"
#include "custom_interfaces/msg/detail/robot_cpu__functions.h"
#include "custom_interfaces/msg/detail/robot_cpu__type_support.h"

#endif  // CUSTOM_INTERFACES__MSG__ROBOT_CPU_H_
