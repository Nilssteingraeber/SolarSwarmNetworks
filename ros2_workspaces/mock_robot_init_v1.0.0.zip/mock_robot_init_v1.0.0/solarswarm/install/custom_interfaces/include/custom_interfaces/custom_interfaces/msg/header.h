// generated from rosidl_generator_c/resource/idl.h.em
// with input from custom_interfaces:msg/Header.idl
// generated code does not contain a copyright notice

#ifndef CUSTOM_INTERFACES__MSG__HEADER_H_
#define CUSTOM_INTERFACES__MSG__HEADER_H_

#include "custom_interfaces/msg/detail/header__struct.h"
#include "custom_interfaces/msg/detail/header__functions.h"
#include "custom_interfaces/msg/detail/header__type_support.h"

#endif  // CUSTOM_INTERFACES__MSG__HEADER_H_
