// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from custom_interfaces:msg/RobotQuaternion.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "custom_interfaces/msg/robot_quaternion.hpp"


#ifndef CUSTOM_INTERFACES__MSG__DETAIL__ROBOT_QUATERNION__BUILDER_HPP_
#define CUSTOM_INTERFACES__MSG__DETAIL__ROBOT_QUATERNION__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "custom_interfaces/msg/detail/robot_quaternion__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace custom_interfaces
{

namespace msg
{

namespace builder
{

class Init_RobotQuaternion_w
{
public:
  explicit Init_RobotQuaternion_w(::custom_interfaces::msg::RobotQuaternion & msg)
  : msg_(msg)
  {}
  ::custom_interfaces::msg::RobotQuaternion w(::custom_interfaces::msg::RobotQuaternion::_w_type arg)
  {
    msg_.w = std::move(arg);
    return std::move(msg_);
  }

private:
  ::custom_interfaces::msg::RobotQuaternion msg_;
};

class Init_RobotQuaternion_z
{
public:
  explicit Init_RobotQuaternion_z(::custom_interfaces::msg::RobotQuaternion & msg)
  : msg_(msg)
  {}
  Init_RobotQuaternion_w z(::custom_interfaces::msg::RobotQuaternion::_z_type arg)
  {
    msg_.z = std::move(arg);
    return Init_RobotQuaternion_w(msg_);
  }

private:
  ::custom_interfaces::msg::RobotQuaternion msg_;
};

class Init_RobotQuaternion_y
{
public:
  explicit Init_RobotQuaternion_y(::custom_interfaces::msg::RobotQuaternion & msg)
  : msg_(msg)
  {}
  Init_RobotQuaternion_z y(::custom_interfaces::msg::RobotQuaternion::_y_type arg)
  {
    msg_.y = std::move(arg);
    return Init_RobotQuaternion_z(msg_);
  }

private:
  ::custom_interfaces::msg::RobotQuaternion msg_;
};

class Init_RobotQuaternion_x
{
public:
  explicit Init_RobotQuaternion_x(::custom_interfaces::msg::RobotQuaternion & msg)
  : msg_(msg)
  {}
  Init_RobotQuaternion_y x(::custom_interfaces::msg::RobotQuaternion::_x_type arg)
  {
    msg_.x = std::move(arg);
    return Init_RobotQuaternion_y(msg_);
  }

private:
  ::custom_interfaces::msg::RobotQuaternion msg_;
};

class Init_RobotQuaternion_header
{
public:
  Init_RobotQuaternion_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RobotQuaternion_x header(::custom_interfaces::msg::RobotQuaternion::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_RobotQuaternion_x(msg_);
  }

private:
  ::custom_interfaces::msg::RobotQuaternion msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::custom_interfaces::msg::RobotQuaternion>()
{
  return custom_interfaces::msg::builder::Init_RobotQuaternion_header();
}

}  // namespace custom_interfaces

#endif  // CUSTOM_INTERFACES__MSG__DETAIL__ROBOT_QUATERNION__BUILDER_HPP_
