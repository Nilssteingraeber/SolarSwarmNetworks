// generated from rosidl_generator_c/resource/idl.h.em
// with input from custom_interfaces:msg/RobotMisc.idl
// generated code does not contain a copyright notice

#ifndef CUSTOM_INTERFACES__MSG__ROBOT_MISC_H_
#define CUSTOM_INTERFACES__MSG__ROBOT_MISC_H_

#include "custom_interfaces/msg/detail/robot_misc__struct.h"
#include "custom_interfaces/msg/detail/robot_misc__functions.h"
#include "custom_interfaces/msg/detail/robot_misc__type_support.h"

#endif  // CUSTOM_INTERFACES__MSG__ROBOT_MISC_H_
