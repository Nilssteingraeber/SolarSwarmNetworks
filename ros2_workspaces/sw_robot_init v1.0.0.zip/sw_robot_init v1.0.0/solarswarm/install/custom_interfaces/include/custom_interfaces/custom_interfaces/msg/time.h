// generated from rosidl_generator_c/resource/idl.h.em
// with input from custom_interfaces:msg/Time.idl
// generated code does not contain a copyright notice

#ifndef CUSTOM_INTERFACES__MSG__TIME_H_
#define CUSTOM_INTERFACES__MSG__TIME_H_

#include "custom_interfaces/msg/detail/time__struct.h"
#include "custom_interfaces/msg/detail/time__functions.h"
#include "custom_interfaces/msg/detail/time__type_support.h"

#endif  // CUSTOM_INTERFACES__MSG__TIME_H_
