// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CUSTOM_INTERFACES__MSG__ROBOT_CPU_HPP_
#define CUSTOM_INTERFACES__MSG__ROBOT_CPU_HPP_

#include "custom_interfaces/msg/detail/robot_cpu__struct.hpp"
#include "custom_interfaces/msg/detail/robot_cpu__builder.hpp"
#include "custom_interfaces/msg/detail/robot_cpu__traits.hpp"
#include "custom_interfaces/msg/detail/robot_cpu__type_support.hpp"

#endif  // CUSTOM_INTERFACES__MSG__ROBOT_CPU_HPP_
