// generated from rosidl_generator_c/resource/idl.h.em
// with input from custom_interfaces:srv/RobotServiceInfo.idl
// generated code does not contain a copyright notice

#ifndef CUSTOM_INTERFACES__SRV__ROBOT_SERVICE_INFO_H_
#define CUSTOM_INTERFACES__SRV__ROBOT_SERVICE_INFO_H_

#include "custom_interfaces/srv/detail/robot_service_info__struct.h"
#include "custom_interfaces/srv/detail/robot_service_info__functions.h"
#include "custom_interfaces/srv/detail/robot_service_info__type_support.h"

#endif  // CUSTOM_INTERFACES__SRV__ROBOT_SERVICE_INFO_H_
