// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from custom_interfaces:msg/RobotPoint.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "custom_interfaces/msg/robot_point.hpp"


#ifndef CUSTOM_INTERFACES__MSG__DETAIL__ROBOT_POINT__BUILDER_HPP_
#define CUSTOM_INTERFACES__MSG__DETAIL__ROBOT_POINT__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "custom_interfaces/msg/detail/robot_point__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace custom_interfaces
{

namespace msg
{

namespace builder
{

class Init_RobotPoint_z
{
public:
  explicit Init_RobotPoint_z(::custom_interfaces::msg::RobotPoint & msg)
  : msg_(msg)
  {}
  ::custom_interfaces::msg::RobotPoint z(::custom_interfaces::msg::RobotPoint::_z_type arg)
  {
    msg_.z = std::move(arg);
    return std::move(msg_);
  }

private:
  ::custom_interfaces::msg::RobotPoint msg_;
};

class Init_RobotPoint_y
{
public:
  explicit Init_RobotPoint_y(::custom_interfaces::msg::RobotPoint & msg)
  : msg_(msg)
  {}
  Init_RobotPoint_z y(::custom_interfaces::msg::RobotPoint::_y_type arg)
  {
    msg_.y = std::move(arg);
    return Init_RobotPoint_z(msg_);
  }

private:
  ::custom_interfaces::msg::RobotPoint msg_;
};

class Init_RobotPoint_x
{
public:
  explicit Init_RobotPoint_x(::custom_interfaces::msg::RobotPoint & msg)
  : msg_(msg)
  {}
  Init_RobotPoint_y x(::custom_interfaces::msg::RobotPoint::_x_type arg)
  {
    msg_.x = std::move(arg);
    return Init_RobotPoint_y(msg_);
  }

private:
  ::custom_interfaces::msg::RobotPoint msg_;
};

class Init_RobotPoint_nid
{
public:
  Init_RobotPoint_nid()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RobotPoint_x nid(::custom_interfaces::msg::RobotPoint::_nid_type arg)
  {
    msg_.nid = std::move(arg);
    return Init_RobotPoint_x(msg_);
  }

private:
  ::custom_interfaces::msg::RobotPoint msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::custom_interfaces::msg::RobotPoint>()
{
  return custom_interfaces::msg::builder::Init_RobotPoint_nid();
}

}  // namespace custom_interfaces

#endif  // CUSTOM_INTERFACES__MSG__DETAIL__ROBOT_POINT__BUILDER_HPP_
