// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from custom_interfaces:msg/RobotBattery.idl
// generated code does not contain a copyright notice

#include "custom_interfaces/msg/detail/robot_battery__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_custom_interfaces
const rosidl_type_hash_t *
custom_interfaces__msg__RobotBattery__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0xda, 0xb8, 0x94, 0x62, 0xf9, 0xf5, 0x11, 0x5d,
      0xe2, 0x35, 0x1a, 0xd8, 0x36, 0x2c, 0xaa, 0xb2,
      0x9b, 0xf4, 0xba, 0xd2, 0xb1, 0x45, 0x1f, 0x82,
      0xd6, 0xe9, 0xd0, 0x4e, 0x22, 0xc0, 0xd2, 0xc9,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types
#include "custom_interfaces/msg/detail/time__functions.h"
#include "custom_interfaces/msg/detail/header__functions.h"

// Hashes for external referenced types
#ifndef NDEBUG
static const rosidl_type_hash_t custom_interfaces__msg__Header__EXPECTED_HASH = {1, {
    0x79, 0xa6, 0xc8, 0xe2, 0xf3, 0x07, 0x4f, 0x77,
    0xb7, 0x88, 0x11, 0x0e, 0x42, 0x25, 0x3f, 0x35,
    0x00, 0x39, 0x6a, 0xb2, 0xcc, 0xff, 0x50, 0xa4,
    0xc2, 0xa0, 0x50, 0x1b, 0xfb, 0x05, 0x3a, 0x40,
  }};
static const rosidl_type_hash_t custom_interfaces__msg__Time__EXPECTED_HASH = {1, {
    0xa7, 0x43, 0xee, 0x7d, 0x12, 0x75, 0x3d, 0xbf,
    0x6f, 0xe4, 0x5d, 0xe7, 0x28, 0xc5, 0x90, 0xa8,
    0xd5, 0xde, 0x5d, 0xa6, 0x6f, 0xfb, 0xa8, 0x5f,
    0x95, 0x99, 0xa8, 0xf3, 0x3a, 0xcc, 0x58, 0x7d,
  }};
#endif

static char custom_interfaces__msg__RobotBattery__TYPE_NAME[] = "custom_interfaces/msg/RobotBattery";
static char custom_interfaces__msg__Header__TYPE_NAME[] = "custom_interfaces/msg/Header";
static char custom_interfaces__msg__Time__TYPE_NAME[] = "custom_interfaces/msg/Time";

// Define type names, field names, and default values
static char custom_interfaces__msg__RobotBattery__FIELD_NAME__header[] = "header";
static char custom_interfaces__msg__RobotBattery__FIELD_NAME__data[] = "data";

static rosidl_runtime_c__type_description__Field custom_interfaces__msg__RobotBattery__FIELDS[] = {
  {
    {custom_interfaces__msg__RobotBattery__FIELD_NAME__header, 6, 6},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {custom_interfaces__msg__Header__TYPE_NAME, 28, 28},
    },
    {NULL, 0, 0},
  },
  {
    {custom_interfaces__msg__RobotBattery__FIELD_NAME__data, 4, 4},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_DOUBLE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

static rosidl_runtime_c__type_description__IndividualTypeDescription custom_interfaces__msg__RobotBattery__REFERENCED_TYPE_DESCRIPTIONS[] = {
  {
    {custom_interfaces__msg__Header__TYPE_NAME, 28, 28},
    {NULL, 0, 0},
  },
  {
    {custom_interfaces__msg__Time__TYPE_NAME, 26, 26},
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
custom_interfaces__msg__RobotBattery__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {custom_interfaces__msg__RobotBattery__TYPE_NAME, 34, 34},
      {custom_interfaces__msg__RobotBattery__FIELDS, 2, 2},
    },
    {custom_interfaces__msg__RobotBattery__REFERENCED_TYPE_DESCRIPTIONS, 2, 2},
  };
  if (!constructed) {
    assert(0 == memcmp(&custom_interfaces__msg__Header__EXPECTED_HASH, custom_interfaces__msg__Header__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[0].fields = custom_interfaces__msg__Header__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&custom_interfaces__msg__Time__EXPECTED_HASH, custom_interfaces__msg__Time__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[1].fields = custom_interfaces__msg__Time__get_type_description(NULL)->type_description.fields;
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "Header header\n"
  "float64 data";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
custom_interfaces__msg__RobotBattery__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {custom_interfaces__msg__RobotBattery__TYPE_NAME, 34, 34},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 27, 27},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
custom_interfaces__msg__RobotBattery__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[3];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 3, 3};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *custom_interfaces__msg__RobotBattery__get_individual_type_description_source(NULL),
    sources[1] = *custom_interfaces__msg__Header__get_individual_type_description_source(NULL);
    sources[2] = *custom_interfaces__msg__Time__get_individual_type_description_source(NULL);
    constructed = true;
  }
  return &source_sequence;
}
