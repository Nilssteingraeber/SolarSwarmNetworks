// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from custom_interfaces:msg/RobotActivity.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "custom_interfaces/msg/robot_activity.h"


#ifndef CUSTOM_INTERFACES__MSG__DETAIL__ROBOT_ACTIVITY__STRUCT_H_
#define CUSTOM_INTERFACES__MSG__DETAIL__ROBOT_ACTIVITY__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

// Include directives for member types
// Member 'nid'
// Member 'activity'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/RobotActivity in the package custom_interfaces.
typedef struct custom_interfaces__msg__RobotActivity
{
  rosidl_runtime_c__String nid;
  rosidl_runtime_c__String activity;
} custom_interfaces__msg__RobotActivity;

// Struct for a sequence of custom_interfaces__msg__RobotActivity.
typedef struct custom_interfaces__msg__RobotActivity__Sequence
{
  custom_interfaces__msg__RobotActivity * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} custom_interfaces__msg__RobotActivity__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // CUSTOM_INTERFACES__MSG__DETAIL__ROBOT_ACTIVITY__STRUCT_H_
