// generated from rosidl_generator_c/resource/idl.h.em
// with input from custom_interfaces:msg/NeighborList.idl
// generated code does not contain a copyright notice

#ifndef CUSTOM_INTERFACES__MSG__NEIGHBOR_LIST_H_
#define CUSTOM_INTERFACES__MSG__NEIGHBOR_LIST_H_

#include "custom_interfaces/msg/detail/neighbor_list__struct.h"
#include "custom_interfaces/msg/detail/neighbor_list__functions.h"
#include "custom_interfaces/msg/detail/neighbor_list__type_support.h"

#endif  // CUSTOM_INTERFACES__MSG__NEIGHBOR_LIST_H_
