// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CUSTOM_INTERFACES__MSG__ROBOT_QUATERNION_HPP_
#define CUSTOM_INTERFACES__MSG__ROBOT_QUATERNION_HPP_

#include "custom_interfaces/msg/detail/robot_quaternion__struct.hpp"
#include "custom_interfaces/msg/detail/robot_quaternion__builder.hpp"
#include "custom_interfaces/msg/detail/robot_quaternion__traits.hpp"
#include "custom_interfaces/msg/detail/robot_quaternion__type_support.hpp"

#endif  // CUSTOM_INTERFACES__MSG__ROBOT_QUATERNION_HPP_
