// generated from rosidl_generator_c/resource/idl.h.em
// with input from custom_interfaces:srv/SetRobotActivity.idl
// generated code does not contain a copyright notice

#ifndef CUSTOM_INTERFACES__SRV__SET_ROBOT_ACTIVITY_H_
#define CUSTOM_INTERFACES__SRV__SET_ROBOT_ACTIVITY_H_

#include "custom_interfaces/srv/detail/set_robot_activity__struct.h"
#include "custom_interfaces/srv/detail/set_robot_activity__functions.h"
#include "custom_interfaces/srv/detail/set_robot_activity__type_support.h"

#endif  // CUSTOM_INTERFACES__SRV__SET_ROBOT_ACTIVITY_H_
