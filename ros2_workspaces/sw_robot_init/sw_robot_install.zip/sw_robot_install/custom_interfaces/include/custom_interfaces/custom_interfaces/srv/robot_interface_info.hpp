// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CUSTOM_INTERFACES__SRV__ROBOT_INTERFACE_INFO_HPP_
#define CUSTOM_INTERFACES__SRV__ROBOT_INTERFACE_INFO_HPP_

#include "custom_interfaces/srv/detail/robot_interface_info__struct.hpp"
#include "custom_interfaces/srv/detail/robot_interface_info__builder.hpp"
#include "custom_interfaces/srv/detail/robot_interface_info__traits.hpp"
#include "custom_interfaces/srv/detail/robot_interface_info__type_support.hpp"

#endif  // CUSTOM_INTERFACES__SRV__ROBOT_INTERFACE_INFO_HPP_
