// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CUSTOM_INTERFACES__SRV__ROBOT_SERVICE_INFO_HPP_
#define CUSTOM_INTERFACES__SRV__ROBOT_SERVICE_INFO_HPP_

#include "custom_interfaces/srv/detail/robot_service_info__struct.hpp"
#include "custom_interfaces/srv/detail/robot_service_info__builder.hpp"
#include "custom_interfaces/srv/detail/robot_service_info__traits.hpp"
#include "custom_interfaces/srv/detail/robot_service_info__type_support.hpp"

#endif  // CUSTOM_INTERFACES__SRV__ROBOT_SERVICE_INFO_HPP_
