from sqlalchemy import Column, Integer, String, Float, ForeignKey, BigInteger, JSON
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship

Base = declarative_base()

class Robot(Base):
    __tablename__ = "robot"
    
    robot_id = Column(Integer, primary_key=True, index=True)
    nid = Column(String(64), unique=True, index=True)
    state_id = Column(Integer, ForeignKey("state.state_id"))
    display_name = Column(String(64))
    ipv4 = Column(String(16))
    ipv6 = Column(String(40))
    mac = Column(String(24))
    
    statuses = relationship("Status", back_populates="robot")
    state_changes = relationship("StateChange", back_populates="robot")
    state = relationship("State", back_populates="robots")

class Status(Base):
    __tablename__ = "status"
    
    status_id = Column(Integer, primary_key=True, index=True)
    robot_id = Column(Integer, ForeignKey("robot.robot_id"))
    battery = Column(Float)  # double precision
    cpu_1 = Column(Float)    # double precision
    point = Column(JSON)
    orientation = Column(JSON)
    last_heard = Column(BigInteger)
    
    robot = relationship("Robot", back_populates="statuses")

class Neighbor(Base):
    __tablename__ = "neighbor"
    
    robot_id = Column(Integer, ForeignKey("robot.robot_id"), primary_key=True)
    neighbor = Column(Integer, ForeignKey("robot.robot_id"), primary_key=True)
    strength = Column(Float)  # real
    
    robot = relationship("Robot", foreign_keys=[robot_id])
    neighbor_robot = relationship("Robot", foreign_keys=[neighbor])

class State(Base):
    __tablename__ = "state"
    
    state_id = Column(Integer, primary_key=True, index=True)
    state = Column(String(64))
    
    robots = relationship("Robot", back_populates="state")
    state_changes = relationship("StateChange", back_populates="state")

class StateChange(Base):
    __tablename__ = "statechange"
    
    change_id = Column(Integer, primary_key=True, index=True)
    state_id = Column(Integer, ForeignKey("state.state_id"))
    robot_id = Column(Integer, ForeignKey("robot.robot_id"))
    begin = Column(BigInteger)
    
    state = relationship("State", back_populates="state_changes")
    robot = relationship("Robot", back_populates="state_changes")