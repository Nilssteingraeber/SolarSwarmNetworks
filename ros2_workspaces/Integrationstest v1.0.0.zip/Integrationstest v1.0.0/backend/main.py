from fastapi import FastAPI, HTTPException, Depends
from pydantic import BaseModel
from typing import List, Optional, Any, Dict
import models
from database import engine, SessionLocal
from sqlalchemy.orm import Session
import json
import subprocess

app = FastAPI()
models.Base.metadata.create_all(bind=engine)

# Pydantic Modelle
class StatusBase(BaseModel):
    robot_id: int
    battery: Optional[float] = None
    cpu_1: Optional[float] = None
    point: Optional[Dict[str, Any]] = None
    orientation: Optional[Dict[str, Any]] = None
    last_heard: int

# Erbt alles aus dem Statusbase, um die Datenabzufragen.
# Gebraucht, wenn wir Daten abfragen wollen
class StatusResponse(StatusBase):
    status_id: int
    
    class Config:
        from_attributes = True # Automatische Umwandlung in JSON, sodass FastAPI interpretieren kann

class RobotBase(BaseModel):
    nid: str
    state_id: Optional[int] = None
    display_name: Optional[str] = None
    ipv4: Optional[str] = None
    ipv6: Optional[str] = None
    mac: Optional[str] = None

class RobotResponse(RobotBase):
    robot_id: int
    
    class Config:
        from_attributes = True

class NeighborBase(BaseModel):
    robot_id: int
    neighbor: int
    strength: Optional[float] = None

class NeighborResponse(NeighborBase):
    class Config:
        from_attributes = True

class StateBase(BaseModel):
    state: str

class StateResponse(StateBase):
    state_id: int
    
    class Config:
        from_attributes = True

class StateChangeBase(BaseModel):
    state_id: int
    robot_id: int
    begin: int

class StateChangeResponse(StateChangeBase):
    change_id: int
    
    class Config:
        from_attributes = True

# Datenbankverbindung
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

db_dependency = Depends(get_db)

# Status Endpunkte
@app.get("/status/", response_model=List[StatusResponse])
def read_all_status(skip: int = 0, limit: int = 100, db: Session = db_dependency):
    return db.query(models.Status).offset(skip).limit(limit).all()

# Abfrage nach dem richtigen Status
@app.get("/status/{status_id}", response_model=StatusResponse)
def read_status(status_id: int, db: Session = db_dependency):
    status = db.query(models.Status).filter(models.Status.status_id == status_id).first() # Filter ist wie WHERE
    if not status:
        raise HTTPException(status_code=404, detail="Status not found")
    return status

# Genauere Abfrage nach einem Roboter mit einer bestimmten ID
# Hier könnte eine Abfrage nach dem Service hinein.
@app.get("/status/robot/{robot_id}", response_model=List[StatusResponse])
def read_status_by_robot(robot_id: int, db: Session = db_dependency):
    return db.query(models.Status).filter(models.Status.robot_id == robot_id).all()

# Erstellen eines Statuses
@app.post("/status/", response_model=StatusResponse)
def create_status(status: StatusBase, db: Session = db_dependency):
    db_status = models.Status(**status.model_dump()) # Eingehendes Pydantic Modell in Dict. Neue SQLAlchemy Instanz
    db.add(db_status)
    db.commit()
    db.refresh(db_status)
    return db_status

# Genauer Status löschen
@app.delete("/status/{status_id}")
def delete_status(status_id: int, db: Session = db_dependency):
    status = db.query(models.Status).filter(models.Status.status_id == status_id).first()
    if not status:
        raise HTTPException(status_code=404, detail="Status not found")
    db.delete(status)
    db.commit()
    return {"message": "Status deleted successfully"}

# ----------------------------Robot Endpunkte-----------------------------------------------
@app.get("/robot/", response_model=List[RobotResponse])
def read_all_robots(skip: int = 0, limit: int = 100, db: Session = db_dependency):
    return db.query(models.Robot).offset(skip).limit(limit).all()

@app.get("/robot/{robot_id}", response_model=RobotResponse)
def read_robot(robot_id: int, db: Session = db_dependency):
    robot = db.query(models.Robot).filter(models.Robot.robot_id == robot_id).first()
    if not robot:
        raise HTTPException(status_code=404, detail="Robot not found")
    return robot

@app.get("/robot/nid/{nid}", response_model=RobotResponse)
def read_robot_by_nid(nid: str, db: Session = db_dependency):
    robot = db.query(models.Robot).filter(models.Robot.nid == nid).first()
    if not robot:
        raise HTTPException(status_code=404, detail="Robot not found")
    return robot

@app.post("/robot/", response_model=RobotResponse)
def create_robot(robot: RobotBase, db: Session = db_dependency):
    db_robot = models.Robot(**robot.model_dump())
    db.add(db_robot)
    db.commit()
    db.refresh(db_robot)
    return db_robot

@app.delete("/robot/{robot_id}")
def delete_robot(robot_id: int, db: Session = db_dependency):
    robot = db.query(models.Robot).filter(models.Robot.robot_id == robot_id).first()
    if not robot:
        raise HTTPException(status_code=404, detail="Robot not found")
    db.delete(robot)
    db.commit()
    return {"message": "Robot deleted successfully"}

# Befehle für den Roboter
@app.post("/robot/{robot_id}/start")
def start_robot(nid: str):
    try:
        # Beispiel-Service call
        cmd = [
            "ros2", "service", "call",
            f"/robot/{nid}/start",
            "my_robot_msgs/srv/Start"
        ]
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        return {"output": result.stdout}
    except subprocess.CalledProcessError as e:
        raise HTTPException(status_code=500, detail=e.stderr)

# Nachbar Endpunkte
@app.get("/neighbor/", response_model=List[NeighborResponse])
def read_all_neighbors(skip: int = 0, limit: int = 100, db: Session = db_dependency):
    return db.query(models.Neighbor).offset(skip).limit(limit).all()

@app.get("/neighbor/robot/{robot_id}", response_model=List[NeighborResponse])
def read_neighbors_by_robot(robot_id: int, db: Session = db_dependency):
    return db.query(models.Neighbor).filter(models.Neighbor.robot_id == robot_id).all()

@app.post("/neighbor/", response_model=NeighborResponse)
def create_neighbor(neighbor: NeighborBase, db: Session = db_dependency):
    db_neighbor = models.Neighbor(**neighbor.model_dump())
    db.add(db_neighbor)
    db.commit()
    db.refresh(db_neighbor)
    return db_neighbor

@app.delete("/neighbor/")
def delete_neighbor(robot_id: int, neighbor: int, db: Session = db_dependency):
    neighbor_entry = db.query(models.Neighbor).filter(
        models.Neighbor.robot_id == robot_id,
        models.Neighbor.neighbor == neighbor
    ).first()
    
    if not neighbor_entry:
        raise HTTPException(status_code=404, detail="Neighbor relationship not found")
    
    db.delete(neighbor_entry)
    db.commit()
    return {"message": "Neighbor relationship deleted successfully"}

# State Endpunkte
@app.get("/state/", response_model=List[StateResponse])
def read_all_states(db: Session = db_dependency):
    return db.query(models.State).all()

@app.post("/state/", response_model=StateResponse)
def create_state(state: StateBase, db: Session = db_dependency):
    db_state = models.State(**state.model_dump())
    db.add(db_state)
    db.commit()
    db.refresh(db_state)
    return db_state

# StateChange Endpunkte
@app.get("/statechange/", response_model=List[StateChangeResponse])
def read_all_state_changes(skip: int = 0, limit: int = 100, db: Session = db_dependency):
    return db.query(models.StateChange).offset(skip).limit(limit).all()

@app.post("/statechange/", response_model=StateChangeResponse)
def create_state_change(state_change: StateChangeBase, db: Session = db_dependency):
    db_state_change = models.StateChange(**state_change.model_dump())
    db.add(db_state_change)
    db.commit()
    db.refresh(db_state_change)
    return db_state_change

# Service Endpunkte schreiben
# Lernen einen Service zu schreiben
# Mit Docker eine Verbindung schaffen -> Dockerfile schreiben
# Testservice machen, schauen ob diese ankommt zwischen FastAPI und ROS2
# 