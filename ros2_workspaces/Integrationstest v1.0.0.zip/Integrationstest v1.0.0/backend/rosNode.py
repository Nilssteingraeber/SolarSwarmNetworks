import rclpy
from rclpy.node import Node
from turtlesim.msg import Pose
import requests
import os

# Skript ggf benutzen für OS Calls im ROS Container/Package
# IN der FASTAPi den Request kommen und das Python Skript dann ausführen.
# Fast api und ROS Nodes kommunikation / Vereinen? Aus ROS Node ein FASTAPI Endpunkt
# ROS CLI. Mit dem Service Call machen? 2 Service calls ob das mit Service hat eigene Funktionen Service Call mit Namen.
# Das mit API Verbinden? Services kennen und die NID dran hängen.
# Vincent Dokumentation nachschauen
# Durch API Calls die NID. Mit Fronend von Nils
# Output der Konsole mit popen
# MIt der ROS Middleware
# ROS nochmal mit dem Package anschauen -> Wie kann ich custom Skripts ausführen? Muss erst gesourced werden

# Erstmal ein Skript machen, welches "Roboter tut XY" sagt. Wenn ein Endpunkt geklickt wird.

# Codebase in GTP einlesen und fragen

# Eine neue Datenbank von Nils einbauen
# 


class TurtlePoseSubscriber(Node):


    def __init__(self):
        super().__init__('turtle_pose_subscriber')
        self.subscription = self.create_subscription(
            Pose,
            '/turtle1/pose',
            self.listener_callback,
            1)
        self.subscription  # prevent unused variable warning

    def listener_callback(self, msg):
        payload = {
            "robot_id": 1,
            "x": msg.x,
            "y": msg.y,
            "theta": msg.theta,
            "linear_velocity": msg.linear_velocity,
            "angular_velocity": msg.angular_velocity
        }

        try:
            response = requests.post("http://localhost:8000/rosrobot/", json=payload)
            self.get_logger().info(f"Daten gesendet: {payload} -> {response.status_code}")
        except Exception as e:
            self.get_logger().error(f"Fehler beim Senden: {e}")

def main(args=None):
    rclpy.init(args=args)
    node = TurtlePoseSubscriber()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
