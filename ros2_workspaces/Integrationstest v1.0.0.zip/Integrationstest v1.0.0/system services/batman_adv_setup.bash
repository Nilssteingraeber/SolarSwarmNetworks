#!/bin/bash
set -e # exit program if one command fails (as subsequent ones are unlikely to succeed then)

WLANDEV="" # replace this

if [ $(echo $WLANDEV | wc --chars) -eq 1 ]; then
  >&2 echo "Error: WLANDEV was not set for batman_advanced_setup service"
  exit 1
fi

# Kernel-Module (neu) laden
sudo modprobe batman_adv
sudo modprobe -r iwlwifi
sudo modprobe iwlwifi
sleep 1

# Reset Interface
sudo ip link set $WLANDEV down
sudo iwconfig $WLANDEV mode managed
sudo ip link set $WLANDEV up
sleep 1

sudo ip link set $WLANDEV down

# Setze auf IBSS
sudo iwconfig $WLANDEV mode ad-hoc
sudo ip link set $WLANDEV up mtu 1560
sudo ip link set $WLANDEV promisc on
sleep 1

# Join IBSS
sudo iw dev $WLANDEV ibss join mymesh 2412

# bat0 hinzufügen
sudo batctl if add $WLANDEV
sudo ip link set up dev bat0

# IP zuteilen
sudo avahi-autoipd bat0
echo "Done"
