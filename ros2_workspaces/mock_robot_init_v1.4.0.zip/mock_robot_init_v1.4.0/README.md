# Einleitung
Dieses Verzeichnis beinhaltet alle notwendigen Dateien für den Start eines Mock-Roboters. Ein Mock-Roboter ist ein WLAN-fähiger Rechner mit Linux (Ubuntu) als Betriebssystem. Wegen der Anforderungen an dieses Projekt werden andere Distributionen oder ältere Versionen als Ubuntu 24.04 nicht getestet. Der Start setzt neben dem Betriebssystem eine Internetverbindung für die Vorbereitung voraus. 

# Vorbereitung
## Kernel-Module
Stelle sicher, dass die Kernel-Module `batman_adv` und `iwlwifi` verfügbar sind:
```bash
    find /lib/modules/$(uname -r) -type f -name '*.ko*'
```
Referenz: https://unix.stackexchange.com/a/184880

## Command Line Tools
Zur Ausführung von `batman_adv_setup.bash`:
```bash
    sudp apt update
    sudo apt install iw
    sudo apt install batctl
    sudo apt install avahi-autoipd
```

## Docker
Eine ordentliche Installation von Docker erfordert mehrere Schritte, welche sich nicht in einem Skript automatisieren lassen. Sollte Docker nicht installiert sein, orientiere Dich bitte am offiziellen Guide: https://docs.docker.com/engine/install/

Zur Ausführung von ROS2 Nodes wird das Image `ros:jazzy` verwendet: 
```bash
    sudo docker pull ros:jazzy # optional, da es sonst beim Bauen installiert wird
```

Ist Docker installiert und funktionsfähig, kann der Mock-Roboter manuell (zu Testzwecken) oder mit Docker Compose von diesem Verzeichnis aus gebaut werden mit
```bash
    sudo docker build --tag mock_robot .
    # später starten mit: sudo docker run mock_robot
```
oder
```bash
    sudo docker compose build
```

## Services einrichten
Das Verzeichnis `system services/` beinhaltet drei Services: *batman_adv_setup* richtet Batman-Adv ein und tritt einem Ad-hoc Netzwerk bei. Wenn `enabled`, wird Batman-Adv nach Boot des Systems eingerichtet. *batman_adv_healthcheck* prüft, ob Batman-Adv Nachbarn sieht und startet *batman_adv_setup* neu, sollte ca. 25 Sekunden lang kein Nachbar gesichtet worden sein. *iw_dump* wird benötigt, um automatisiert Informationen zu Nachbarn im Netzwerk zu ermitteln und sie in Containern verfügbar zu machen. 

`service_helper.bash` hilt dabei, die Services auf einem Linux-System einzurichten. Das Skript informiert über gültige Parameter, wenn es ohne welche ausgeführt wird (etwa mit `bash service_helper.bash`). Zu beachten ist, dass das Skript für die meisten Befehle Root-Rechte benötigt. Daher vor der Ausführung sollte sichergestellt werden, dass nichts an diesem Skript oder den Services verändert wurde, was dem System schaden könnte.

> Hinweis: *batman_adv_setup* und *iw_dump* erfordern das Anlegen einer Umgebungsvariablen `WLANDEV`, welche ein gültiges Wlan-Interface nennen sollte. Mit `ip link` lassen sich Netzwerk-Interfaces anzeigen. Wlan-Interfaces fangen üblicherweise mit "wlan" oder "wl" an (üblich ist "wlan0"). Die Intel NUCs verfügen über "wlp0s20f3". Mit `sudo bash service_helper.bash wlandev` kann für eine angegebene Bezeichnung eine permanente Umgebungsvariable in `/etc/environment` angelegt werden. Sie wird überschrieben, falls bereits eine hinterlegt wurde.

## Dockerfile
Die Dockerfile legt `/home/ubuntu/solarswarm` als Arbeitsverzeichnis fest und kopiert benötigte Dateien dort hinein. Das Docker Image `ros:jazzy` hat das zum entpacken von ZIP-Dateien häufig verwendete Tool `unzip` nicht vorinstalliert, weshalb diesem Verzeichnis ein Skript `unzip.py` beiliegt, welches mit vorinstallierten Python-Modulen ZIP-Dateien in ein gleichnamiges Verzeichnis entpacken kann. Dazu kann je Datei eine Zeile in `mock_robot_init.bash` hinzugefügt werden, beispielsweise so:
```bash
    python3 unzip.py "install.zip"; # creates directory install/
```

| Datei | Funktion |
|-------|----------|
| solarswarm | ROS2 Arbeitsverzeichnis mit dem Source Code der Packages `mock_robot` und `custom_interfaces`. |
| unzip.py | Winziges Python-Skript, welches in `mock_data_init` übergebene Dateien entpackt. |
| mock_data_init.bash | Bash-Skript, welches als Entrypoint der Dockerfile ausgeführt wird. Es kann `unzip.py` ausführen, lädt das Overlay und startet die `mock_data` Node. |

# Start
## bat0 einrichten
Wurde der Service *batman_adv_setup* eingerichtet und `enabled`, sollte bat0 einige Sekunden nach Systemstart automatisch eingerichtet werden. Ansonsten kann dieser einzeln mit `sudo systemctl start batman_adv_setup` gestartet werden. Falls die Services nicht verwendet werden, kann `system services/batman_adv_setup.bash` mit Root-Rechten manuell ausgeführt werden. Jedoch muss die Umgebungsvariable `WLANDEV` angelegt worden (s.o.) oder die Variable manuell in dem Skript überschrieben worden sein. Für letztere Herangehensweise empfiehlt es sich, das Skript erst zu kopieren, ehe Änderungen vorgenommen werden.

## Container starten
Von diesem Verzeichnis aus startet `sudo docker compose up` den Container mit dem Mock-Roboter. Die ROS2 Node `mock_data` beginnt dann, Nachrichten zu veröffentlichen. 

Nach dem Start lässt sich der Container manuell inspizieren:
```bash
    # auf dem Host
    sudo docker ps # ID des zu inspizierenden Containers kopieren
    sudo docker exec -it <Container ID> bash # ID einfügen

    # im Container, falls mit `ros2` manuell Befehle ausgeführt werden sollen
    source /opt/ros/jazzy/setup.bash
    source install/localsetup.bash
```
