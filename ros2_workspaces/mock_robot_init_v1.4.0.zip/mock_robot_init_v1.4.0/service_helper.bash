#!/bin/bash
if [ -z $1 ]; then
    echo """    Correct usage:
        bash service_helper [wlandev | setup | cleanup | restart |
            stop | enable | disable | managed]
    Params:
        wlandev [wireless interface] - input wlan device
    	setup - copy files, make scripts executable, reload systemd,
    	    enable timer, and restart all services
    	cleanup - remove services and files
    	restart [batman_adv_setup | batman_adv_healthcheck | iw_dump]
    	stop [batman_adv_setup | batman_adv_healthcheck | iw_dump]
    	enable [batman_adv_setup | batman_adv_healthcheck | iw_dump]
    	disable [batman_adv_setup | batman_adv_healthcheck | iw_dump]
        managed - return from ad-hoc to managed mode (required for
            internet access)
    Notes:
        - Ensure that 'system services/batman_adv_setup.bash' uses
            the correct wireless interface to set up ad-hoc mode. To
            disable ad-hoc, use the 'managed' option.
        - Enabled services and timers start automatically after boot.
            A service can be disabled and active at the same time.
    """
    exit 1
fi

echo_valid_names() {
    echo "Unknown name. Use any of:
    batman_adv_setup
    batman_adv_healthcheck
    iw_dump"
}


echo "Warning: This script is executed with root priviliges and uses
    the files present in 'system services/' to configure services on
    this machine. As this poses a security risk, make sure the content
    of the *.bash files and service_helper.bash script's content was
    not altered. Only files from 'system services/' and their
    respective service names should be used."
echo "Continue? y/N "
read continue
if [ -z $continue ] || [ $continue == "N" ] || [ $continue == "n" ]; then
    exit 0
fi


if [ $1 == "wlandev" ]; then
    if [ -z $2 ]; then
        echo "Input your wireless interface (leave empty to use wlp0s20f3) "
        read wlandev
        if [ -z $wlandev ]; then
            wlandev=wlp0s20f3
        fi
    else
        wlandev=$2
    fi
    if [[ $wlandev == *['!'@#\$%^\&*\(\)+]* ]]; then
        echo "Error: Input contains illegal characters"
        exit 1
    fi
    # export WLANDEV=$wlandev
    sudo sed -i "/WLANDEV=/d" /etc/environment
    echo "WLANDEV=\"$wlandev\"" | sudo tee -a /etc/environment > /dev/null
    echo "Exported $wlandev"
    source /etc/environment
elif [ $1 == "setup" ]; then
    echo "Starting setup..."
    mkdir /tmp/iw_dump
    sudo cp system\ services/*.bash /usr/local/bin/
    sudo chmod +x /usr/local/bin/batman_adv_setup.bash
    sudo chmod +x /usr/local/bin/batman_adv_healthcheck.bash
    sudo chmod +x /usr/local/bin/iw_dump.bash
    
    sudo cp system\ services/*.service /etc/systemd/system/
    sudo cp system\ services/*.timer /etc/systemd/system/
    
    sudo systemctl daemon-reload
    sudo systemctl restart batman_adv_setup.service
    sudo systemctl restart batman_adv_healthcheck.service
    
    sudo systemctl enable batman_adv_setup.service
    sudo systemctl enable batman_adv_healthcheck.service
    sudo systemctl enable --now iw_dump.timer
elif [ $1 == "cleanup" ]; then
    echo "Starting cleanup..."
    sudo systemctl stop batman_adv_healthcheck.service
    sudo systemctl stop batman_adv_setup.service
    
    sudo systemctl disable batman_adv_healthcheck.service
    sudo systemctl disable batman_adv_setup.service
    sudo systemctl disable --now iw_dump.timer 1> /dev/null
    
    sudo rm -f /etc/systemd/system/batman_adv_setup.service
    sudo rm -f /etc/systemd/system/batman_adv_healthcheck.service
    sudo rm -f /etc/systemd/system/iw_dump.service
    sudo rm -f /etc/systemd/system/iw_dump.timer
    sudo rm -f /usr/local/bin/batman_adv_setup.bash
    sudo rm -f /usr/local/bin/batman_adv_healthcheck.bash
    rm -rf /tmp/iw_dump/
elif [ $1 == "restart" ]; then
    if [ -z $2 ]; then
	    sudo systemctl restart batman_adv_setup.service
	    sudo systemctl restart batman_adv_healthcheck.service
        sudo systemctl start iw_dump.timer
    elif [ $2 == "batman_adv_setup" ]; then
    	sudo systemctl restart batman_adv_setup.service
    elif [ $2 == "batman_adv_healthcheck" ]; then
    	sudo systemctl restart batman_adv_healthcheck.service
    elif [ $2 == "iw_dump" ]; then
        sudo systemctl restart iw_dump.timer
    else
        echo_valid_names
    fi
elif [ $1 == "stop" ]; then
    if [ -z $2 ]; then
	    sudo systemctl stop batman_adv_setup.service
	    sudo systemctl stop batman_adv_healthcheck.service
        sudo systemctl stop iw_dump.timer
    elif [ $2 == "batman_adv_setup" ]; then
    	sudo systemctl stop batman_adv_setup.service
    elif [ $2 == "batman_adv_healthcheck" ]; then
    	sudo systemctl stop batman_adv_healthcheck.service
    elif [ $2 == "iw_dump" ]; then
        sudo systemctl stop iw_dump.timer # useless?
    else
        echo_valid_names
    fi
elif [ $1 == "enable" ]; then
    if [ -z $2 ]; then
	    sudo systemctl enable batman_adv_setup.service
	    sudo systemctl enable batman_adv_healthcheck.service
        sudo systemctl enable iw_dump.timer
    elif [ $2 == "batman_adv_setup" ]; then
    	sudo systemctl enable batman_adv_setup.service
    elif [ $2 == "batman_adv_healthcheck" ]; then
    	sudo systemctl enable batman_adv_healthcheck.service
    elif [ $2 == "iw_dump" ]; then
    	sudo systemctl enable iw_dump.timer 1> /dev/null
    else
        echo_valid_names
    fi
elif [ $1 == "disable" ]; then
    if [ -z $2 ]; then
	    sudo systemctl disable batman_adv_setup.service
	    sudo systemctl disable batman_adv_healthcheck.service
    elif [ $2 == "batman_adv_setup" ]; then
    	sudo systemctl disable batman_adv_setup.service
    elif [ $2 == "batman_adv_healthcheck" ]; then
    	sudo systemctl disable batman_adv_healthcheck.service
    elif [ $2 == "iw_dump" ]; then
    	sudo systemctl disable iw_dump.timer 1> /dev/null
    else
        echo_valid_names
    fi
elif [ $1 == "managed" ]; then
    sudo systemctl stop batman_adv_setup.service 2>/dev/null
    sudo systemctl stop batman_adv_healthcheck.service 2>/dev/null
    sudo systemctl stop iw_dump.timer 2>/dev/null

    sudo ip link set bat0 down 2>/dev/null
    sudo batctl if del $WLANDEV 2>/dev/null
    sudo ip link set $WLANDEV down
    sudo iwconfig $WLANDEV mode managed
    sudo ip link set $WLANDEV up
fi
