// generated from rosidl_generator_c/resource/idl.h.em
// with input from custom_interfaces:srv/RobotInterfaceInfo.idl
// generated code does not contain a copyright notice

#ifndef CUSTOM_INTERFACES__SRV__ROBOT_INTERFACE_INFO_H_
#define CUSTOM_INTERFACES__SRV__ROBOT_INTERFACE_INFO_H_

#include "custom_interfaces/srv/detail/robot_interface_info__struct.h"
#include "custom_interfaces/srv/detail/robot_interface_info__functions.h"
#include "custom_interfaces/srv/detail/robot_interface_info__type_support.h"

#endif  // CUSTOM_INTERFACES__SRV__ROBOT_INTERFACE_INFO_H_
