// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from custom_interfaces:msg/RobotPoint.idl
// generated code does not contain a copyright notice

#include "custom_interfaces/msg/detail/robot_point__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_custom_interfaces
const rosidl_type_hash_t *
custom_interfaces__msg__RobotPoint__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0xaa, 0x9b, 0x1a, 0x36, 0x59, 0xd6, 0x12, 0x84,
      0x25, 0x25, 0xa5, 0xdc, 0x52, 0x08, 0xae, 0x8a,
      0x1d, 0xd2, 0xd0, 0x6a, 0x83, 0x14, 0xfd, 0x13,
      0xb5, 0xc6, 0xfe, 0xe7, 0x90, 0x18, 0x6f, 0xb1,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char custom_interfaces__msg__RobotPoint__TYPE_NAME[] = "custom_interfaces/msg/RobotPoint";

// Define type names, field names, and default values
static char custom_interfaces__msg__RobotPoint__FIELD_NAME__nid[] = "nid";
static char custom_interfaces__msg__RobotPoint__FIELD_NAME__x[] = "x";
static char custom_interfaces__msg__RobotPoint__FIELD_NAME__y[] = "y";
static char custom_interfaces__msg__RobotPoint__FIELD_NAME__z[] = "z";

static rosidl_runtime_c__type_description__Field custom_interfaces__msg__RobotPoint__FIELDS[] = {
  {
    {custom_interfaces__msg__RobotPoint__FIELD_NAME__nid, 3, 3},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {custom_interfaces__msg__RobotPoint__FIELD_NAME__x, 1, 1},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_DOUBLE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {custom_interfaces__msg__RobotPoint__FIELD_NAME__y, 1, 1},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_DOUBLE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {custom_interfaces__msg__RobotPoint__FIELD_NAME__z, 1, 1},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_DOUBLE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
custom_interfaces__msg__RobotPoint__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {custom_interfaces__msg__RobotPoint__TYPE_NAME, 32, 32},
      {custom_interfaces__msg__RobotPoint__FIELDS, 4, 4},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "string nid\n"
  "float64 x\n"
  "float64 y\n"
  "float64 z";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
custom_interfaces__msg__RobotPoint__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {custom_interfaces__msg__RobotPoint__TYPE_NAME, 32, 32},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 41, 41},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
custom_interfaces__msg__RobotPoint__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *custom_interfaces__msg__RobotPoint__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
