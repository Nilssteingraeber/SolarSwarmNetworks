// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from custom_interfaces:msg/RobotMisc.idl
// generated code does not contain a copyright notice

#include "custom_interfaces/msg/detail/robot_misc__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_custom_interfaces
const rosidl_type_hash_t *
custom_interfaces__msg__RobotMisc__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x25, 0x72, 0x9e, 0x40, 0x94, 0xf4, 0xd1, 0xea,
      0x0a, 0xca, 0x20, 0x43, 0xc7, 0x02, 0xdf, 0xdd,
      0x4a, 0x2f, 0xdb, 0x9c, 0x2c, 0xb9, 0xd6, 0xda,
      0x38, 0x99, 0x28, 0x40, 0xe0, 0x63, 0x17, 0x4c,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char custom_interfaces__msg__RobotMisc__TYPE_NAME[] = "custom_interfaces/msg/RobotMisc";

// Define type names, field names, and default values
static char custom_interfaces__msg__RobotMisc__FIELD_NAME__nid[] = "nid";
static char custom_interfaces__msg__RobotMisc__FIELD_NAME__data[] = "data";

static rosidl_runtime_c__type_description__Field custom_interfaces__msg__RobotMisc__FIELDS[] = {
  {
    {custom_interfaces__msg__RobotMisc__FIELD_NAME__nid, 3, 3},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {custom_interfaces__msg__RobotMisc__FIELD_NAME__data, 4, 4},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
custom_interfaces__msg__RobotMisc__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {custom_interfaces__msg__RobotMisc__TYPE_NAME, 31, 31},
      {custom_interfaces__msg__RobotMisc__FIELDS, 2, 2},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "string nid\n"
  "string data";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
custom_interfaces__msg__RobotMisc__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {custom_interfaces__msg__RobotMisc__TYPE_NAME, 31, 31},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 23, 23},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
custom_interfaces__msg__RobotMisc__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *custom_interfaces__msg__RobotMisc__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
