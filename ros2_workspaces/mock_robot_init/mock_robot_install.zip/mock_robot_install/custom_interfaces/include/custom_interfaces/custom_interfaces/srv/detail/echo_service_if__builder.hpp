// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from custom_interfaces:srv/EchoServiceIf.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "custom_interfaces/srv/echo_service_if.hpp"


#ifndef CUSTOM_INTERFACES__SRV__DETAIL__ECHO_SERVICE_IF__BUILDER_HPP_
#define CUSTOM_INTERFACES__SRV__DETAIL__ECHO_SERVICE_IF__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "custom_interfaces/srv/detail/echo_service_if__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace custom_interfaces
{

namespace srv
{

namespace builder
{

class Init_EchoServiceIf_Request_msg
{
public:
  explicit Init_EchoServiceIf_Request_msg(::custom_interfaces::srv::EchoServiceIf_Request & msg)
  : msg_(msg)
  {}
  ::custom_interfaces::srv::EchoServiceIf_Request msg(::custom_interfaces::srv::EchoServiceIf_Request::_msg_type arg)
  {
    msg_.msg = std::move(arg);
    return std::move(msg_);
  }

private:
  ::custom_interfaces::srv::EchoServiceIf_Request msg_;
};

class Init_EchoServiceIf_Request_nid
{
public:
  Init_EchoServiceIf_Request_nid()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_EchoServiceIf_Request_msg nid(::custom_interfaces::srv::EchoServiceIf_Request::_nid_type arg)
  {
    msg_.nid = std::move(arg);
    return Init_EchoServiceIf_Request_msg(msg_);
  }

private:
  ::custom_interfaces::srv::EchoServiceIf_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::custom_interfaces::srv::EchoServiceIf_Request>()
{
  return custom_interfaces::srv::builder::Init_EchoServiceIf_Request_nid();
}

}  // namespace custom_interfaces


namespace custom_interfaces
{

namespace srv
{

namespace builder
{

class Init_EchoServiceIf_Response_msg
{
public:
  Init_EchoServiceIf_Response_msg()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::custom_interfaces::srv::EchoServiceIf_Response msg(::custom_interfaces::srv::EchoServiceIf_Response::_msg_type arg)
  {
    msg_.msg = std::move(arg);
    return std::move(msg_);
  }

private:
  ::custom_interfaces::srv::EchoServiceIf_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::custom_interfaces::srv::EchoServiceIf_Response>()
{
  return custom_interfaces::srv::builder::Init_EchoServiceIf_Response_msg();
}

}  // namespace custom_interfaces


namespace custom_interfaces
{

namespace srv
{

namespace builder
{

class Init_EchoServiceIf_Event_response
{
public:
  explicit Init_EchoServiceIf_Event_response(::custom_interfaces::srv::EchoServiceIf_Event & msg)
  : msg_(msg)
  {}
  ::custom_interfaces::srv::EchoServiceIf_Event response(::custom_interfaces::srv::EchoServiceIf_Event::_response_type arg)
  {
    msg_.response = std::move(arg);
    return std::move(msg_);
  }

private:
  ::custom_interfaces::srv::EchoServiceIf_Event msg_;
};

class Init_EchoServiceIf_Event_request
{
public:
  explicit Init_EchoServiceIf_Event_request(::custom_interfaces::srv::EchoServiceIf_Event & msg)
  : msg_(msg)
  {}
  Init_EchoServiceIf_Event_response request(::custom_interfaces::srv::EchoServiceIf_Event::_request_type arg)
  {
    msg_.request = std::move(arg);
    return Init_EchoServiceIf_Event_response(msg_);
  }

private:
  ::custom_interfaces::srv::EchoServiceIf_Event msg_;
};

class Init_EchoServiceIf_Event_info
{
public:
  Init_EchoServiceIf_Event_info()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_EchoServiceIf_Event_request info(::custom_interfaces::srv::EchoServiceIf_Event::_info_type arg)
  {
    msg_.info = std::move(arg);
    return Init_EchoServiceIf_Event_request(msg_);
  }

private:
  ::custom_interfaces::srv::EchoServiceIf_Event msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::custom_interfaces::srv::EchoServiceIf_Event>()
{
  return custom_interfaces::srv::builder::Init_EchoServiceIf_Event_info();
}

}  // namespace custom_interfaces

#endif  // CUSTOM_INTERFACES__SRV__DETAIL__ECHO_SERVICE_IF__BUILDER_HPP_
