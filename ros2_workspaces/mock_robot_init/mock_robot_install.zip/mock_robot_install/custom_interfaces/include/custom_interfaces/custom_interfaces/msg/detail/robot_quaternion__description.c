// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from custom_interfaces:msg/RobotQuaternion.idl
// generated code does not contain a copyright notice

#include "custom_interfaces/msg/detail/robot_quaternion__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_custom_interfaces
const rosidl_type_hash_t *
custom_interfaces__msg__RobotQuaternion__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x32, 0x46, 0x14, 0xc7, 0x32, 0xd6, 0x2d, 0xfe,
      0x9b, 0x5d, 0xa4, 0xa1, 0xc9, 0xf1, 0x27, 0x1c,
      0xef, 0x28, 0x72, 0xde, 0x1a, 0x95, 0x66, 0xea,
      0xea, 0xf7, 0xce, 0x70, 0xd9, 0xe0, 0x95, 0x10,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char custom_interfaces__msg__RobotQuaternion__TYPE_NAME[] = "custom_interfaces/msg/RobotQuaternion";

// Define type names, field names, and default values
static char custom_interfaces__msg__RobotQuaternion__FIELD_NAME__nid[] = "nid";
static char custom_interfaces__msg__RobotQuaternion__FIELD_NAME__x[] = "x";
static char custom_interfaces__msg__RobotQuaternion__FIELD_NAME__y[] = "y";
static char custom_interfaces__msg__RobotQuaternion__FIELD_NAME__z[] = "z";
static char custom_interfaces__msg__RobotQuaternion__FIELD_NAME__w[] = "w";

static rosidl_runtime_c__type_description__Field custom_interfaces__msg__RobotQuaternion__FIELDS[] = {
  {
    {custom_interfaces__msg__RobotQuaternion__FIELD_NAME__nid, 3, 3},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {custom_interfaces__msg__RobotQuaternion__FIELD_NAME__x, 1, 1},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_DOUBLE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {custom_interfaces__msg__RobotQuaternion__FIELD_NAME__y, 1, 1},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_DOUBLE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {custom_interfaces__msg__RobotQuaternion__FIELD_NAME__z, 1, 1},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_DOUBLE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {custom_interfaces__msg__RobotQuaternion__FIELD_NAME__w, 1, 1},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_DOUBLE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
custom_interfaces__msg__RobotQuaternion__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {custom_interfaces__msg__RobotQuaternion__TYPE_NAME, 37, 37},
      {custom_interfaces__msg__RobotQuaternion__FIELDS, 5, 5},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "string nid\n"
  "float64 x\n"
  "float64 y\n"
  "float64 z\n"
  "float64 w";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
custom_interfaces__msg__RobotQuaternion__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {custom_interfaces__msg__RobotQuaternion__TYPE_NAME, 37, 37},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 51, 51},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
custom_interfaces__msg__RobotQuaternion__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *custom_interfaces__msg__RobotQuaternion__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
