// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from custom_interfaces:srv/SetRobotActivity.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "custom_interfaces/srv/set_robot_activity.hpp"


#ifndef CUSTOM_INTERFACES__SRV__DETAIL__SET_ROBOT_ACTIVITY__BUILDER_HPP_
#define CUSTOM_INTERFACES__SRV__DETAIL__SET_ROBOT_ACTIVITY__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "custom_interfaces/srv/detail/set_robot_activity__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace custom_interfaces
{

namespace srv
{

namespace builder
{

class Init_SetRobotActivity_Request_details
{
public:
  explicit Init_SetRobotActivity_Request_details(::custom_interfaces::srv::SetRobotActivity_Request & msg)
  : msg_(msg)
  {}
  ::custom_interfaces::srv::SetRobotActivity_Request details(::custom_interfaces::srv::SetRobotActivity_Request::_details_type arg)
  {
    msg_.details = std::move(arg);
    return std::move(msg_);
  }

private:
  ::custom_interfaces::srv::SetRobotActivity_Request msg_;
};

class Init_SetRobotActivity_Request_activity
{
public:
  Init_SetRobotActivity_Request_activity()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SetRobotActivity_Request_details activity(::custom_interfaces::srv::SetRobotActivity_Request::_activity_type arg)
  {
    msg_.activity = std::move(arg);
    return Init_SetRobotActivity_Request_details(msg_);
  }

private:
  ::custom_interfaces::srv::SetRobotActivity_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::custom_interfaces::srv::SetRobotActivity_Request>()
{
  return custom_interfaces::srv::builder::Init_SetRobotActivity_Request_activity();
}

}  // namespace custom_interfaces


namespace custom_interfaces
{

namespace srv
{

namespace builder
{

class Init_SetRobotActivity_Response_msg
{
public:
  Init_SetRobotActivity_Response_msg()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::custom_interfaces::srv::SetRobotActivity_Response msg(::custom_interfaces::srv::SetRobotActivity_Response::_msg_type arg)
  {
    msg_.msg = std::move(arg);
    return std::move(msg_);
  }

private:
  ::custom_interfaces::srv::SetRobotActivity_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::custom_interfaces::srv::SetRobotActivity_Response>()
{
  return custom_interfaces::srv::builder::Init_SetRobotActivity_Response_msg();
}

}  // namespace custom_interfaces


namespace custom_interfaces
{

namespace srv
{

namespace builder
{

class Init_SetRobotActivity_Event_response
{
public:
  explicit Init_SetRobotActivity_Event_response(::custom_interfaces::srv::SetRobotActivity_Event & msg)
  : msg_(msg)
  {}
  ::custom_interfaces::srv::SetRobotActivity_Event response(::custom_interfaces::srv::SetRobotActivity_Event::_response_type arg)
  {
    msg_.response = std::move(arg);
    return std::move(msg_);
  }

private:
  ::custom_interfaces::srv::SetRobotActivity_Event msg_;
};

class Init_SetRobotActivity_Event_request
{
public:
  explicit Init_SetRobotActivity_Event_request(::custom_interfaces::srv::SetRobotActivity_Event & msg)
  : msg_(msg)
  {}
  Init_SetRobotActivity_Event_response request(::custom_interfaces::srv::SetRobotActivity_Event::_request_type arg)
  {
    msg_.request = std::move(arg);
    return Init_SetRobotActivity_Event_response(msg_);
  }

private:
  ::custom_interfaces::srv::SetRobotActivity_Event msg_;
};

class Init_SetRobotActivity_Event_info
{
public:
  Init_SetRobotActivity_Event_info()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SetRobotActivity_Event_request info(::custom_interfaces::srv::SetRobotActivity_Event::_info_type arg)
  {
    msg_.info = std::move(arg);
    return Init_SetRobotActivity_Event_request(msg_);
  }

private:
  ::custom_interfaces::srv::SetRobotActivity_Event msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::custom_interfaces::srv::SetRobotActivity_Event>()
{
  return custom_interfaces::srv::builder::Init_SetRobotActivity_Event_info();
}

}  // namespace custom_interfaces

#endif  // CUSTOM_INTERFACES__SRV__DETAIL__SET_ROBOT_ACTIVITY__BUILDER_HPP_
