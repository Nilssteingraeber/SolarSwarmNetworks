// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from custom_interfaces:msg/NeighborList.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "custom_interfaces/msg/neighbor_list.hpp"


#ifndef CUSTOM_INTERFACES__MSG__DETAIL__NEIGHBOR_LIST__BUILDER_HPP_
#define CUSTOM_INTERFACES__MSG__DETAIL__NEIGHBOR_LIST__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "custom_interfaces/msg/detail/neighbor_list__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace custom_interfaces
{

namespace msg
{

namespace builder
{

class Init_NeighborList_indicators
{
public:
  explicit Init_NeighborList_indicators(::custom_interfaces::msg::NeighborList & msg)
  : msg_(msg)
  {}
  ::custom_interfaces::msg::NeighborList indicators(::custom_interfaces::msg::NeighborList::_indicators_type arg)
  {
    msg_.indicators = std::move(arg);
    return std::move(msg_);
  }

private:
  ::custom_interfaces::msg::NeighborList msg_;
};

class Init_NeighborList_neighbors
{
public:
  explicit Init_NeighborList_neighbors(::custom_interfaces::msg::NeighborList & msg)
  : msg_(msg)
  {}
  Init_NeighborList_indicators neighbors(::custom_interfaces::msg::NeighborList::_neighbors_type arg)
  {
    msg_.neighbors = std::move(arg);
    return Init_NeighborList_indicators(msg_);
  }

private:
  ::custom_interfaces::msg::NeighborList msg_;
};

class Init_NeighborList_header
{
public:
  Init_NeighborList_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_NeighborList_neighbors header(::custom_interfaces::msg::NeighborList::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_NeighborList_neighbors(msg_);
  }

private:
  ::custom_interfaces::msg::NeighborList msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::custom_interfaces::msg::NeighborList>()
{
  return custom_interfaces::msg::builder::Init_NeighborList_header();
}

}  // namespace custom_interfaces

#endif  // CUSTOM_INTERFACES__MSG__DETAIL__NEIGHBOR_LIST__BUILDER_HPP_
