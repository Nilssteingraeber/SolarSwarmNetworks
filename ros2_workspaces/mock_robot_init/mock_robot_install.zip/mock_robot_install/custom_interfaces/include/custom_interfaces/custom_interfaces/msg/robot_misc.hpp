// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CUSTOM_INTERFACES__MSG__ROBOT_MISC_HPP_
#define CUSTOM_INTERFACES__MSG__ROBOT_MISC_HPP_

#include "custom_interfaces/msg/detail/robot_misc__struct.hpp"
#include "custom_interfaces/msg/detail/robot_misc__builder.hpp"
#include "custom_interfaces/msg/detail/robot_misc__traits.hpp"
#include "custom_interfaces/msg/detail/robot_misc__type_support.hpp"

#endif  // CUSTOM_INTERFACES__MSG__ROBOT_MISC_HPP_
