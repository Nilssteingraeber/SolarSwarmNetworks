import rclpy
from rclpy.node import Node
# from rcl_interfaces.msg import ParameterDescriptor
# from example_interfaces.msg import String
# from example_interfaces.msg import Float64
# from geometry_msgs.msg import Point
# from geometry_msgs.msg import Quaternion
from custom_interfaces.msg import RobotBattery
from custom_interfaces.msg import RobotCpu
from custom_interfaces.msg import RobotPoint
from custom_interfaces.msg import RobotQuaternion
from custom_interfaces.msg import RobotMisc

import json

class RobotStatusSub(Node):
    def __init__(self):
        super().__init__("robot_status_sub")
        self.__battery_sub = self.create_subscription(RobotBattery, 'robot_battery', self.battery_callback, 3)
        self.__cpu_sub = self.create_subscription(RobotCpu, 'robot_cpu', self.cpu_callback, 3)
        self.__point_sub = self.create_subscription(RobotPoint, 'robot_point', self.point_callback, 3)
        self.__orientation_sub = self.create_subscription(RobotQuaternion, 'robot_orientation', self.orientation_callback, 3)
        self.__misc_sub = self.create_subscription(RobotMisc, 'robot_misc', self.misc_callback, 3)
        print('DEBUG: Subscribers initialized')
        
        print(self.get_node_names_and_namespaces())
        
    def battery_callback(self, msg):
        print(f"Battery of {msg.nid}: {msg.data}")
    
    def cpu_callback(self, msg):
        print(f"CPU of {msg.nid}: {msg.data}")
    
    def point_callback(self, msg):
        print(f"Point of {msg.nid}: {msg.x}\t{msg.y}\t{msg.z}")
    
    def orientation_callback(self, msg):
        print(f"Orientation of {msg.nid}: {msg.x}\t{msg.y}\t{msg.z}\t{msg.w}")
    
    def misc_callback(self, msg):
        data = json.loads(msg.data)
        print(f"JSON of {msg.nid}: {data}")
    
    def get_battery_sub(self):
        return self.__battery_sub
    
    def get_cpu_sub(self):
        return self.__cpu_sub
    
    def get_point_sub(self):
        return self.__point_sub
        
    def get_orientation_sub(self):
        return self.__orientation_sub
    
    def get_misc_sub(self):
        return self.__misc_sub
    
def main():
    # rclpy starten
    rclpy.init()

    # Node starten
    robot_status_sub = RobotStatusSub()
    rclpy.spin(robot_status_sub)
    
    # Node zerstören
    robot_status_sub.destroy_node()
    
    # rclpy beenden
    rclpy.shutdown()


if __name__ == "__main__":
    main()
