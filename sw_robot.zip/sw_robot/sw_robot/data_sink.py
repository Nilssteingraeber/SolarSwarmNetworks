import rclpy
from rclpy.node import Node
from rcl_interfaces.msg import ParameterDescriptor
from example_interfaces.msg import String
from example_interfaces.msg import Float64
from geometry_msgs.msg import Point
from geometry_msgs.msg import Quaternion

import json

class RobotStatusSub(Node):
    def __init__(self):
        super().__init__("robot_status_sub")
        self.__battery_sub = self.create_subscription(Float64, 'robot_battery', self.battery_callback, 3)
        self.__cpu_sub = self.create_subscription(Float64, 'robot_cpu', self.cpu_callback, 3)
        self.__point_sub = self.create_subscription(Point, 'robot_point', self.point_callback, 3)
        self.__orientation_sub = self.create_subscription(Quaternion, 'robot_orientation', self.orientation_callback, 3)
        self.__misc_sub = self.create_subscription(String, 'robot_misc', self.misc_callback, 3)
        print('DEBUG: Subscribers initialized')
        
        print(self.get_node_names_and_namespaces())
        
    def battery_callback(self, msg):
        print("Battery:", msg.data)
    
    def cpu_callback(self, msg):
        print("CPU:", msg.data)
    
    def point_callback(self, msg):
        print("Point:", msg.x, msg.y, msg.z)
    
    def orientation_callback(self, msg):
        print("Orientation:", msg.x, msg.y, msg.z, msg.w)
    
    def misc_callback(self, msg):
        data = json.loads(msg.data)
        print("JSON:", data)
    
    def get_battery_sub(self):
        return self.__battery_sub
    
    def get_cpu_sub(self):
        return self.__cpu_sub
    
    def get_point_sub(self):
        return self.__point_sub
        
    def get_orientation_sub(self):
        return self.__orientation_sub
    
    def get_misc_sub(self):
        return self.__misc_sub
    
def main():
    # rclpy starten
    rclpy.init()

    # Node starten
    robot_status_sub = RobotStatusSub()
    rclpy.spin(robot_status_sub)
    
    # Node zerstören
    robot_status_sub.destroy_node()
    
    # rclpy beenden
    rclpy.shutdown()


if __name__ == "__main__":
    main()
