import rclpy
from rclpy.node import Node
from rcl_interfaces.msg import ParameterDescriptor
# from example_interfaces.msg import String
# from example_interfaces.msg import Float64
# from geometry_msgs.msg import Point
# from geometry_msgs.msg import Quaternion
from custom_interfaces.msg import RobotBattery
from custom_interfaces.msg import RobotCpu
from custom_interfaces.msg import RobotPoint
from custom_interfaces.msg import RobotQuaternion
from custom_interfaces.msg import RobotMisc

import json
from datetime import datetime

class RobotStatusSub(Node):
    def __init__(self):
        super().__init__("robot_status_sub")
        # parameters
        self.declare_parameter('batch_intervall', 30.0, ParameterDescriptor(description='Time it takes the data sink to forward the next batch.'))
        
        # subscriptions
        self.__battery_sub = self.create_subscription(RobotBattery, 'robot_battery', self.battery_callback, 3)
        self.__cpu_sub = self.create_subscription(RobotCpu, 'robot_cpu', self.cpu_callback, 3)
        self.__point_sub = self.create_subscription(RobotPoint, 'robot_point', self.point_callback, 3)
        self.__orientation_sub = self.create_subscription(RobotQuaternion, 'robot_orientation', self.orientation_callback, 3)
        self.__misc_sub = self.create_subscription(RobotMisc, 'robot_misc', self.misc_callback, 3)
        self.get_logger().debug('Subscriptions initialized')
        
        # timer intervalls
        BATCH = rclpy.parameter.parameter_value_to_python(
            self.get_parameter('batch_intervall').get_parameter_value())
        
        # timers
        self.__batch_timer = self.create_timer(BATCH, self.batch_timer_callback)
        self.get_logger().debug('Timers initialized')
        
        # dict to containing most recent info published on each topic per node
        self.__nodes = {}
    
    def __check_node(self, nid): # creates new key in __nodes for unfamiliar nids
        if not nid in self.__nodes.keys():
            self.__nodes[nid] = {}
    
    def forward_batch(self):
        for node in self.__nodes.keys():
            print(f'nid: {node}\t battery: {self.__nodes[node]["battery"]}\t cpu: {self.__nodes[node]["cpu"]}',
                f'point: {self.__nodes[node]["point"]}',
                f'orientation: {self.__nodes[node]["orientation"]}',
                f'misc: {self.__nodes[node]["misc"]}', sep='\n\t', end='\n\n')
    
    # subscription callbacks
    def battery_callback(self, msg):
        self.__check_node(msg.nid)
        self.__nodes[msg.nid]['battery'] = msg.data
    
    def cpu_callback(self, msg):
        self.__check_node(msg.nid)
        self.__nodes[msg.nid]['cpu'] = msg.data
    
    def point_callback(self, msg):
        self.__check_node(msg.nid)
        self.__nodes[msg.nid]['point'] = {'x': msg.x, 'y': msg.y, 'z': msg.z}
    
    def orientation_callback(self, msg):
        self.__check_node(msg.nid)
        self.__nodes[msg.nid]['orientation'] = {'x': msg.x, 'y': msg.y, 'z': msg.z, 'w': msg.w}
    
    def misc_callback(self, msg):
        self.__check_node(msg.nid)
        data = json.loads(msg.data)
        self.__nodes[msg.nid]['misc'] = data
    
    # timer callbacks
    def batch_timer_callback(self):
        self.forward_batch()
        print('%s: Batch forwarded' % (str(datetime.now()),))
    
    # read-only properties
    @property
    def battery_sub(self):
        return self.__battery_sub
    
    @property
    def cpu_sub(self):
        return self.__cpu_sub
    
    @property
    def point_sub(self):
        return self.__point_sub
        
    @property
    def orientation_sub(self):
        return self.__orientation_sub
    
    @property
    def misc_sub(self):
        return self.__misc_sub



def main():
    # rclpy starten
    rclpy.init()

    # Node starten
    robot_status_sub = RobotStatusSub()
    rclpy.spin(robot_status_sub)
    
    # Node zerstören
    robot_status_sub.destroy_node()
    
    # rclpy beenden
    rclpy.shutdown()


if __name__ == "__main__":
    main()
